# 🎓 Saint Michael Technical High School - Official Web Portal & Admissions

A modern, responsive, and bilingual (English & Kinyarwanda) web application for **Saint Michael Technical High School** (A School of Technics). Includes online student admissions, interactive fee calculations & payment guidance (MTN MoMo, Bank of Kigali, BPR, Equity Bank), course exploration across 5 accredited trades, digital printable admission slips, school administrative portal, and a companion PHP 8 & MySQL backend.

---

## 🚀 Quick Deploy to Vercel (Get Your Live Link in 2 Minutes)

You can host this project on **Vercel** for free and get a public live URL (e.g. `https://saint-michael-tech.vercel.app`) just like the one in AI Studio:

### Step 1: Upload the Code to GitHub
Choose either **Option A (Git Terminal)** or **Option B (GitHub Web Browser)**:

#### Option A: Using Git Command Line (Recommended)
1. Go to [github.com/new](https://github.com/new) and create a new repository named `saint-michael-high-school` (leave it public or private, do not initialize with README).
2. Open your project folder in your terminal or VS Code and run:
   ```bash
   git init
   git add .
   git commit -m "Saint Michael Technical High School Portal"
   git branch -M main
   git remote add origin https://github.com/YOUR_GITHUB_USERNAME/saint-michael-high-school.git
   git push -u origin main
   ```

#### Option B: Using GitHub Web Interface (No Git CLI needed)
1. Go to [github.com/new](https://github.com/new) and create a repository.
2. Click **"uploading an existing file"**.
3. Drag and drop all the project files (all files and folders, excluding `node_modules`).
4. Click **"Commit changes"**.

---

### Step 2: Deploy on Vercel
1. Go to [vercel.com](https://vercel.com) and click **Sign Up** or **Log In** (choose **Continue with GitHub**).
2. On your Vercel Dashboard, click **"Add New..."** → **"Project"**.
3. Find your `saint-michael-high-school` repository and click **"Import"**.
4. Vercel automatically detects the project configuration:
   - **Framework Preset**: `Vite`
   - **Root Directory**: `./`
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`
5. Click the blue **"Deploy"** button.
6. 🎉 In 30–60 seconds, your site is live! You will receive your public link:
   ```
   https://saint-michael-high-school.vercel.app
   ```

*(Tip: You can also connect a custom domain like `saintmichael.rw` or `saintmichael.edu` under Vercel Project Settings → Domains).*

---

## 🛠️ Project Structure

```
├── public/                 # Static assets (school crest, videos, PHP backend files)
│   ├── backend/            # PHP 8 backend endpoints & MySQL schema
│   │   ├── admin.php       # Standalone PHP admin dashboard with CSV export
│   │   ├── config.php      # PDO database connection with CORS
│   │   ├── database.sql    # MySQL database schema for XAMPP / MariaDB
│   │   ├── pay.php         # Fee payment recorder API
│   │   └── register.php    # Student admissions registration API
│   ├── images/             # Saint Michael crest & school photos
│   └── videos/             # Background campus & software lab videos
├── src/
│   ├── components/         # React UI Components
│   │   ├── Navbar.tsx      # Bilingual navigation & quick links
│   │   ├── Hero.tsx        # School banner with campus video modal
│   │   ├── ProgramsSection.tsx  # 5 Technical trades with curriculum details
│   │   ├── FeesAndPayment.tsx   # Fees calculator & MoMo/Bank payment instructions
│   │   ├── RegistrationSection.tsx # Admissions form with printable admission slip
│   │   ├── AdminPortal.tsx # Protected admissions registry with CSV export
│   │   ├── PhpBackendCenter.tsx # Interactive PHP & MySQL source inspector
│   │   ├── DownloadModal.tsx # 1-click ZIP exporter for GitHub & Vercel
│   │   ├── ContactSection.tsx # Campus contact details & Google Map locator
│   │   └── Footer.tsx      # Accreditation badges & school copyright
│   ├── data/               # Program data, translations, and PHP source code
│   ├── services/           # Local storage persistence & ZIP generation
│   ├── types/              # TypeScript interfaces
│   ├── App.tsx             # Root application component
│   └── main.tsx            # React application entry point
├── index.html              # HTML5 entry with Cinzel & Plus Jakarta Sans typography
├── package.json            # Dependencies & build scripts
├── tsconfig.json           # TypeScript configuration
├── vercel.json             # Vercel SPA routing rewrite rules
└── vite.config.ts          # Vite build configuration with Tailwind CSS v4
```

---

## 💻 Local Development Setup

To run the project locally on your machine:

1. **Install Node.js** (version 18+ or 20+ recommended) from [nodejs.org](https://nodejs.org).
2. **Install dependencies**:
   ```bash
   npm install
   ```
3. **Start local dev server**:
   ```bash
   npm run dev
   ```
4. Open [http://localhost:3000](http://localhost:3000) in your browser.
5. To test the production build locally:
   ```bash
   npm run build
   npm run preview
   ```

---

## 🗄️ Optional: Connecting to the PHP 8 & MySQL Backend (XAMPP)

The frontend works seamlessly out of the box with built-in client storage (localStorage) and offline-first persistence. 

If you also wish to connect the included PHP 8 & MySQL backend for school server evaluation:
1. Open **XAMPP Control Panel** and start **Apache** and **MySQL**.
2. Copy the contents of the `public/backend/` folder into your XAMPP `htdocs`:
   - Windows: `C:\xampp\htdocs\smths_backend\`
   - macOS: `/Applications/XAMPP/xamppfiles/htdocs/smths_backend/`
3. Open `http://localhost/phpmyadmin` in your browser.
4. Create a database or go to the **SQL** tab and paste the contents of `public/backend/database.sql`.
5. Access the standalone PHP admin dashboard at `http://localhost/smths_backend/admin.php`.

---

## 🌟 Key Features

- **5 Accredited Technical Trades**: Software Development, Food and Beverage, Computer Systems, Architecture, and Multimedia.
- **Bilingual Interface**: Full instant toggle between English and Kinyarwanda (`Ikinyarwanda`).
- **Interactive Admissions**: Real-time validation, registration code generation (`SMTHS-2025-XXXX`), and printable official admission slip (`window.print()`).
- **Rwandan Payment Guide**: Step-by-step instructions for MTN Mobile Money (`*182*8*1*054321#`), Bank of Kigali (`00040-0694821-34`), BPR Bank, and Equity Bank.
- **Admin Management Portal**: Search, filter, approve, and export applicant spreadsheets (CSV).
- **Vercel-Ready SPA Routing**: Comes preconfigured with `vercel.json` rewrite rules so page refreshes and direct links never return 404.

---

## 📄 License & Credits

Built for **Saint Michael Technical High School**. All rights reserved.
