import { StudentRegistration, PaymentRecord, ProgramId } from '../types/index.ts';

const STORAGE_KEY_REG = 'smths_registrations_v1';
const STORAGE_KEY_PAY = 'smths_payments_v1';

const INITIAL_REGISTRATIONS: StudentRegistration[] = [
  {
    id: 'reg_1',
    regCode: 'SMTHS-2025-0101',
    name: 'Mugisha Emmanuel',
    dob: '2007-04-12',
    district: 'Gasabo, Kigali',
    school: 'GS Remera Protestant',
    prog: 'p1',
    parent: 'Habimana Jean Bosco',
    phone: '0788123456',
    email: 'emmanuel.m@gmail.com',
    msg: 'Passion for web design and backend PHP databases.',
    status: 'admitted',
    createdAt: new Date(Date.now() - 86400000 * 3).toISOString()
  },
  {
    id: 'reg_2',
    regCode: 'SMTHS-2025-0102',
    name: 'Keza Diane',
    dob: '2008-01-24',
    district: 'Kicukiro, Kigali',
    school: 'Kagarama Secondary School',
    prog: 'p2',
    parent: 'Mukamana Claudine',
    phone: '0788654321',
    email: 'claudine.m@yahoo.com',
    msg: 'Aspiring professional pastry chef and culinary manager.',
    status: 'verified',
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString()
  },
  {
    id: 'reg_3',
    regCode: 'SMTHS-2025-0103',
    name: 'Uwase Aline',
    dob: '2007-09-18',
    district: 'Nyarugenge, Kigali',
    school: 'Camp Kigali School',
    prog: 'p5',
    parent: 'Karasira Patrick',
    phone: '0788998877',
    email: 'aline.u@outlook.com',
    msg: 'Keen on video production and audio visual animation.',
    status: 'pending',
    createdAt: new Date(Date.now() - 86400000 * 1).toISOString()
  }
];

const INITIAL_PAYMENTS: PaymentRecord[] = [
  {
    id: 'pay_1',
    regCode: 'SMTHS-2025-0101',
    studentName: 'Mugisha Emmanuel',
    phone: '0788123456',
    prog: 'p1',
    method: 'momo',
    amount: 20000,
    itemType: 'registration',
    refNumber: 'TXN-MOMO-94821',
    status: 'completed',
    createdAt: new Date(Date.now() - 86400000 * 3).toISOString()
  },
  {
    id: 'pay_2',
    regCode: 'SMTHS-2025-0102',
    studentName: 'Keza Diane',
    phone: '0788654321',
    prog: 'p2',
    method: 'bk',
    amount: 120000,
    itemType: 'term_tuition',
    refNumber: 'TXN-BK-110492',
    status: 'completed',
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString()
  }
];

export const storageService = {
  getRegistrations(): StudentRegistration[] {
    try {
      const data = localStorage.getItem(STORAGE_KEY_REG);
      if (!data) {
        localStorage.setItem(STORAGE_KEY_REG, JSON.stringify(INITIAL_REGISTRATIONS));
        return INITIAL_REGISTRATIONS;
      }
      return JSON.parse(data);
    } catch {
      return INITIAL_REGISTRATIONS;
    }
  },

  saveRegistration(data: {
    name: string;
    dob: string;
    district: string;
    school: string;
    prog: ProgramId;
    parent: string;
    phone: string;
    email?: string;
    msg?: string;
  }): StudentRegistration {
    const list = this.getRegistrations();
    const currentYear = new Date().getFullYear();
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const regCode = `SMTHS-${currentYear}-${randomSuffix}`;

    const newRecord: StudentRegistration = {
      id: 'reg_' + Date.now(),
      regCode,
      ...data,
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    const updated = [newRecord, ...list];
    try {
      localStorage.setItem(STORAGE_KEY_REG, JSON.stringify(updated));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
    return newRecord;
  },

  updateRegistrationStatus(id: string, status: 'pending' | 'verified' | 'admitted'): void {
    const list = this.getRegistrations();
    const updated = list.map(item => item.id === id ? { ...item, status } : item);
    try {
      localStorage.setItem(STORAGE_KEY_REG, JSON.stringify(updated));
    } catch (e) {
      console.warn(e);
    }
  },

  getPayments(): PaymentRecord[] {
    try {
      const data = localStorage.getItem(STORAGE_KEY_PAY);
      if (!data) {
        localStorage.setItem(STORAGE_KEY_PAY, JSON.stringify(INITIAL_PAYMENTS));
        return INITIAL_PAYMENTS;
      }
      return JSON.parse(data);
    } catch {
      return INITIAL_PAYMENTS;
    }
  },

  savePayment(data: {
    studentName: string;
    phone: string;
    prog: ProgramId;
    method: 'momo' | 'bk' | 'bpr' | 'equity';
    amount: number;
    itemType: 'registration' | 'term_tuition' | 'uniform' | 'materials' | 'full_package';
    regCode?: string;
  }): PaymentRecord {
    const list = this.getPayments();
    const randomSuffix = Math.floor(10000 + Math.random() * 90000);
    const refNumber = `TXN-${data.method.toUpperCase()}-${randomSuffix}`;

    const newRecord: PaymentRecord = {
      id: 'pay_' + Date.now(),
      refNumber,
      ...data,
      status: 'completed',
      createdAt: new Date().toISOString()
    };

    const updated = [newRecord, ...list];
    try {
      localStorage.setItem(STORAGE_KEY_PAY, JSON.stringify(updated));
      
      // If payment is linked to registration code, mark it verified
      if (data.regCode) {
        const regs = this.getRegistrations();
        const matched = regs.find(r => r.regCode.toLowerCase() === data.regCode?.toLowerCase());
        if (matched) {
          this.updateRegistrationStatus(matched.id, 'verified');
        }
      }
    } catch (e) {
      console.warn(e);
    }
    return newRecord;
  },

  exportAsCsv(type: 'registrations' | 'payments'): string {
    if (type === 'registrations') {
      const items = this.getRegistrations();
      const headers = ['ID', 'Reg Code', 'Full Name', 'Date of Birth', 'District', 'School', 'Program', 'Parent', 'Phone', 'Email', 'Status', 'Date'];
      const rows = items.map(r => [
        `"${r.id}"`,
        `"${r.regCode}"`,
        `"${r.name.replace(/"/g, '""')}"`,
        `"${r.dob}"`,
        `"${r.district.replace(/"/g, '""')}"`,
        `"${(r.school || '').replace(/"/g, '""')}"`,
        `"${r.prog}"`,
        `"${r.parent.replace(/"/g, '""')}"`,
        `"${r.phone}"`,
        `"${r.email || ''}"`,
        `"${r.status}"`,
        `"${r.createdAt}"`
      ]);
      return [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    } else {
      const items = this.getPayments();
      const headers = ['ID', 'Txn Ref', 'Reg Code', 'Student Name', 'Phone', 'Program', 'Method', 'Amount (RWF)', 'Category', 'Status', 'Date'];
      const rows = items.map(p => [
        `"${p.id}"`,
        `"${p.refNumber}"`,
        `"${p.regCode || ''}"`,
        `"${p.studentName.replace(/"/g, '""')}"`,
        `"${p.phone}"`,
        `"${p.prog}"`,
        `"${p.method}"`,
        p.amount,
        `"${p.itemType}"`,
        `"${p.status}"`,
        `"${p.createdAt}"`
      ]);
      return [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    }
  },

  exportAsJson(): string {
    return JSON.stringify({
      school: 'Saint Michael Technical High School',
      exportedAt: new Date().toISOString(),
      registrations: this.getRegistrations(),
      payments: this.getPayments()
    }, null, 2);
  }
};
