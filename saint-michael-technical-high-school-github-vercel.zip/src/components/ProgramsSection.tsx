import React, { useState } from 'react';
import { Language, ProgramId } from '../types/index.ts';
import { T } from '../data/translations.ts';
import { PROGRAMS } from '../data/programsData.ts';
import { ChevronRight, CheckCircle2, GraduationCap } from 'lucide-react';

interface ProgramsSectionProps {
  lang: Language;
  onSelectProgram: (progId: ProgramId) => void;
}

export const ProgramsSection: React.FC<ProgramsSectionProps> = ({ lang, onSelectProgram }) => {
  const [selectedTrade, setSelectedTrade] = useState<ProgramId>('p1');
  const t = T[lang];

  const activeProgram = PROGRAMS.find(p => p.id === selectedTrade) || PROGRAMS[0];

  return (
    <section id="programs" className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      
      {/* Header with subtle light hairline rule */}
      <div className="text-left mb-10 pb-6 border-b border-slate-200 dark:border-sky-200/15">
        <div className="flex items-center gap-3 mb-2">
          <span className="h-px w-8 bg-[#0B1F3A] dark:bg-sky-300" aria-hidden="true" />
          <span className="text-xs font-semibold tracking-wider uppercase text-[#1A4073] dark:text-sky-300">
            Technical &amp; Vocational Education Training (TVET)
          </span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-cinzel font-bold text-[#0B1F3A] dark:text-white text-balance">
          {t.programs}
        </h2>
        <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 mt-2 max-w-3xl leading-relaxed">
          {lang === 'en'
            ? 'Saint Michael Technical High School equips students with certified, market-driven hands-on competencies in five high-demand technical trades.'
            : 'Saint Michael Technical High School ifasha abanyeshuri kwiga ubumenyi ngiro bufite agaciro ku isoko ry\'umurimo mu mashami atanu y\'ibanze.'}
        </p>
      </div>

      {/* Grid of 5 Programs + Curriculum Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {PROGRAMS.map((prog) => {
          const isSelected = selectedTrade === prog.id;
          return (
            <div
              key={prog.id}
              onClick={() => setSelectedTrade(prog.id)}
              className={`cursor-pointer rounded-xl p-6 transition-colors duration-200 border relative flex flex-col justify-between text-left ${
                isSelected
                  ? 'bg-[#0B1F3A] dark:bg-[#112D53] text-white border-sky-300/45 shadow-lg'
                  : 'bg-white dark:bg-[#0B1D38] hover:border-[#0B1F3A]/40 dark:hover:border-sky-300/35 text-[#0B1F3A] dark:text-slate-100 border-slate-200 dark:border-sky-200/15 shadow-sm'
              }`}
            >
              <div>
                {/* Top row: SVG Emblem + quiet status */}
                <div className="flex items-start justify-between mb-4">
                  <div
                    className={`w-16 h-16 rounded-xl p-2 flex items-center justify-center border transition-colors ${
                      isSelected
                        ? 'bg-white/10 border-sky-200/25 text-sky-200'
                        : 'bg-[#F8FAFC] dark:bg-[#061121] border-slate-200 dark:border-sky-200/15 text-[#0B1F3A] dark:text-sky-300'
                    }`}
                    dangerouslySetInnerHTML={{
                      __html: `<svg viewBox="0 0 200 200" class="w-12 h-12" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round">${prog.iconSvg}</svg>`
                    }}
                  />
                  <span className={`text-[11px] font-mono ${isSelected ? 'text-sky-200' : 'text-slate-500 dark:text-slate-400'}`}>
                    {prog.id.toUpperCase()} {isSelected ? '· Active' : ''}
                  </span>
                </div>

                <div className="space-y-1.5">
                  <h3 className="text-xl font-bold font-serif leading-snug">
                    {t[prog.id]}
                  </h3>
                  <p className={`text-xs sm:text-sm leading-relaxed ${isSelected ? 'text-slate-200' : 'text-slate-600 dark:text-slate-300'}`}>
                    {t[prog.descKey as keyof typeof t]}
                  </p>
                </div>

                {/* Modules Highlights separated by light hairline */}
                <div className={`mt-4 pt-3 border-t ${isSelected ? 'border-sky-200/15' : 'border-slate-200/80 dark:border-sky-200/15'}`}>
                  <span className={`text-[11px] font-semibold block mb-1.5 ${isSelected ? 'text-sky-200' : 'text-slate-500 dark:text-slate-400'}`}>
                    Key Practical Modules
                  </span>
                  <div className="text-xs leading-relaxed">
                    {prog.modules.slice(0, 3).map((mod, i) => (
                      <React.Fragment key={i}>
                        <span className={isSelected ? 'text-slate-100' : 'text-slate-700 dark:text-slate-200'}>{mod}</span>
                        {i < 2 && <span className={`mx-1.5 ${isSelected ? 'text-sky-300/60' : 'text-slate-400'}`} aria-hidden="true">·</span>}
                      </React.Fragment>
                    ))}
                  </div>
                </div>
              </div>

              {/* Action Footer */}
              <div className={`mt-5 pt-3.5 border-t flex items-center justify-between ${isSelected ? 'border-sky-200/15' : 'border-slate-200/80 dark:border-sky-200/15'}`}>
                <span className={`text-xs font-medium flex items-center gap-1.5 ${isSelected ? 'text-sky-100' : 'text-slate-600 dark:text-slate-300'}`}>
                  <GraduationCap className="w-3.5 h-3.5" /> 3 Years Diploma
                </span>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectProgram(prog.id);
                  }}
                  className={`text-xs font-semibold px-3 py-1.5 rounded-lg flex items-center gap-1 transition-colors whitespace-nowrap shrink-0 ${
                    isSelected
                      ? 'bg-white text-[#0B1F3A] hover:bg-sky-100'
                      : 'bg-[#0B1F3A] text-white hover:bg-[#163868] dark:bg-sky-200 dark:text-[#0B1F3A] dark:hover:bg-white'
                  }`}
                >
                  {t.apply}
                  <ChevronRight className="w-3 h-3" />
                </button>
              </div>

            </div>
          );
        })}

        {/* Trade Details Feature Card (6th slot in grid) */}
        <div className="rounded-xl p-6 border border-slate-300 dark:border-sky-200/20 bg-[#F1F5F9]/80 dark:bg-[#0B1D38] flex flex-col justify-between shadow-sm text-left">
          <div>
            <div className="flex items-center gap-2 text-[#0B1F3A] dark:text-sky-300 font-semibold text-xs uppercase tracking-wider pb-3 mb-3 border-b border-slate-200 dark:border-sky-200/15">
              <GraduationCap className="w-4 h-4" />
              <span>Full Curriculum Overview</span>
            </div>
            <h4 className="font-cinzel text-lg font-bold text-[#0B1F3A] dark:text-white">
              {lang === 'en' ? activeProgram.fullNameEn : activeProgram.fullNameRw}
            </h4>
            <p className="text-xs text-slate-700 dark:text-slate-200 mt-2 font-mono bg-white dark:bg-[#061121] border border-slate-200 dark:border-sky-200/15 p-2.5 rounded-lg">
              Qualification: {activeProgram.award}
            </p>

            <div className="mt-4 space-y-2">
              <span className="text-xs font-semibold text-[#0B1F3A] dark:text-sky-200 block">
                Career Opportunities
              </span>
              <ul className="text-xs space-y-1.5 text-slate-700 dark:text-slate-300">
                {activeProgram.careers.map((career, idx) => (
                  <li key={idx} className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#1A4073] dark:text-sky-300 flex-none" />
                    <span>{career}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-200 dark:border-sky-200/15">
            <a
              href="#register"
              onClick={() => onSelectProgram(activeProgram.id)}
              className="w-full block text-center py-2.5 px-4 bg-[#0B1F3A] text-white dark:bg-sky-200 dark:text-[#0B1F3A] font-semibold rounded-lg text-xs hover:bg-[#163868] dark:hover:bg-white transition-colors"
            >
              Enroll in {t[activeProgram.id]} &rarr;
            </a>
          </div>
        </div>

      </div>

    </section>
  );
};
