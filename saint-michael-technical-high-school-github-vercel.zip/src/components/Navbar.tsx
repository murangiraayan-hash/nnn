import React, { useState } from 'react';
import { Language, Theme } from '../types/index.ts';
import { T } from '../data/translations.ts';
import { PROGRAMS, FEE_SCHEDULE } from '../data/programsData.ts';
import { Sun, Moon, Database, ShieldCheck, Menu, X, ChevronDown, Download } from 'lucide-react';

interface NavbarProps {
  lang: Language;
  onToggleLang: () => void;
  theme: Theme;
  onToggleTheme: () => void;
  onOpenPhpCenter: () => void;
  onOpenAdmin: () => void;
  onOpenDownload: () => void;
  studentCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  lang,
  onToggleLang,
  theme,
  onToggleTheme,
  onOpenPhpCenter,
  onOpenAdmin,
  onOpenDownload,
  studentCount
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeMega, setActiveMega] = useState<'programs' | 'fees' | null>(null);

  const t = T[lang];

  return (
    <header className="sticky top-0 z-50 bg-[#0B1F3A] text-white border-b border-sky-200/20 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-4 h-16">
          
          {/* Brand */}
          <a href="#home" className="flex items-center gap-2.5 group text-left whitespace-nowrap shrink-0">
            <span className="w-8 h-8 rounded-lg bg-white/10 border border-sky-200/30 text-sky-100 flex items-center justify-center font-cinzel font-bold text-sm">
              SM
            </span>
            <span className="font-cinzel font-bold text-sm sm:text-base tracking-wide text-white">
              Saint Michael THS
            </span>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-5 lg:gap-6">
            <a
              href="#home"
              className="py-1 text-sm font-medium text-slate-200 hover:text-white border-b border-transparent hover:border-sky-300 transition-colors whitespace-nowrap shrink-0"
            >
              {t.home}
            </a>

            {/* Programs Mega Menu trigger */}
            <div
              className="relative"
              onMouseEnter={() => setActiveMega('programs')}
              onMouseLeave={() => setActiveMega(null)}
            >
              <a
                href="#programs"
                className="py-1 text-sm font-medium text-slate-200 hover:text-white border-b border-transparent hover:border-sky-300 transition-colors flex items-center gap-1 whitespace-nowrap shrink-0"
              >
                {t.programs}
                <ChevronDown className="w-3.5 h-3.5 opacity-75" />
              </a>

              {activeMega === 'programs' && (
                <div className="absolute left-1/2 -translate-x-1/2 top-full pt-3 w-[680px] z-50">
                  <div className="bg-white dark:bg-[#0B1D38] text-[#0B1F3A] dark:text-slate-100 p-5 rounded-xl border border-slate-200 dark:border-sky-200/20 shadow-xl grid grid-cols-2 gap-3">
                    {PROGRAMS.map((prog) => (
                      <a
                        key={prog.id}
                        href="#programs"
                        className="p-3 rounded-lg border border-slate-200/80 dark:border-sky-200/15 hover:border-[#0B1F3A]/40 dark:hover:border-sky-300/40 hover:bg-slate-50 dark:hover:bg-[#112D53]/60 transition-colors flex items-start gap-3 text-left"
                      >
                        <div
                          className="w-9 h-9 flex-none text-[#0B1F3A] dark:text-sky-300"
                          dangerouslySetInnerHTML={{
                            __html: `<svg viewBox="0 0 200 200" class="w-9 h-9" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round">${prog.iconSvg}</svg>`
                          }}
                        />
                        <div>
                          <strong className="block text-sm font-semibold font-serif text-[#0B1F3A] dark:text-white">
                            {t[prog.id]}
                          </strong>
                          <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-2 mt-0.5">
                            {t[prog.descKey as keyof typeof t]}
                          </p>
                        </div>
                      </a>
                    ))}
                    <div className="col-span-2 pt-3 mt-1 border-t border-slate-200 dark:border-sky-200/15 flex justify-between items-center text-xs">
                      <span className="text-slate-500 dark:text-slate-400">5 Accredited Technical Trades · RTQF Level 3-5</span>
                      <a href="#register" className="font-semibold text-[#0B1F3A] dark:text-sky-300 hover:underline">
                        {t.apply} &rarr;
                      </a>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Fees Mega Menu trigger */}
            <div
              className="relative"
              onMouseEnter={() => setActiveMega('fees')}
              onMouseLeave={() => setActiveMega(null)}
            >
              <a
                href="#fees"
                className="py-1 text-sm font-medium text-slate-200 hover:text-white border-b border-transparent hover:border-sky-300 transition-colors flex items-center gap-1 whitespace-nowrap shrink-0"
              >
                {t.fees}
                <ChevronDown className="w-3.5 h-3.5 opacity-75" />
              </a>

              {activeMega === 'fees' && (
                <div className="absolute left-1/2 -translate-x-1/2 top-full pt-3 w-[540px] z-50">
                  <div className="bg-white dark:bg-[#0B1D38] text-[#0B1F3A] dark:text-slate-100 p-5 rounded-xl border border-slate-200 dark:border-sky-200/20 shadow-xl">
                    <div className="grid grid-cols-2 gap-5 divide-x divide-slate-200 dark:divide-sky-200/15">
                      <div>
                        <h4 className="font-semibold text-xs text-slate-500 dark:text-sky-300 mb-2.5 pb-1.5 border-b border-slate-200 dark:border-sky-200/15">
                          {t.feesT}
                        </h4>
                        <ul className="text-xs space-y-2">
                          {FEE_SCHEDULE.map(item => (
                            <li key={item.id} className="flex justify-between items-center py-1 border-b border-slate-100 dark:border-sky-200/10">
                              <span className="text-slate-700 dark:text-slate-200">{t[item.labelKey as keyof typeof t]}</span>
                              <b className="font-mono tabular-nums text-[#0B1F3A] dark:text-white">{item.amountRwf.toLocaleString()} RWF</b>
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div className="pl-5 flex flex-col justify-between">
                        <div>
                          <h4 className="font-semibold text-xs text-slate-500 dark:text-sky-300 mb-2.5 pb-1.5 border-b border-slate-200 dark:border-sky-200/15">
                            {t.fmethod}
                          </h4>
                          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                            MTN MoMo (*182#) · Bank of Kigali · BPR Bank · Equity Bank
                          </p>
                        </div>
                        <a
                          href="#fees"
                          className="mt-4 inline-block w-full text-center py-2 px-3 bg-[#0B1F3A] dark:bg-sky-200 text-white dark:text-[#0B1F3A] font-semibold rounded-lg text-xs hover:bg-[#163868] dark:hover:bg-white transition-colors"
                        >
                          {t.formT} &rarr;
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <a
              href="#register"
              className="py-1 text-sm font-medium text-slate-200 hover:text-white border-b border-transparent hover:border-sky-300 transition-colors whitespace-nowrap shrink-0"
            >
              {t.register}
            </a>

            <a
              href="#contact"
              className="py-1 text-sm font-medium text-slate-200 hover:text-white border-b border-transparent hover:border-sky-300 transition-colors whitespace-nowrap shrink-0"
            >
              {t.contact}
            </a>
          </nav>

          {/* Right Action Tools */}
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={onOpenDownload}
              title="Download Complete School Project & Source Code (.ZIP)"
              className="px-2.5 py-1.5 text-xs font-medium rounded-lg border border-sky-200/25 bg-white/10 hover:bg-white/20 text-white transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0"
            >
              <Download className="w-3.5 h-3.5 text-sky-200" />
              <span className="hidden lg:inline">Export ZIP</span>
            </button>

            <button
              onClick={onOpenPhpCenter}
              title="View and download complete PHP & MySQL backend files"
              className="px-2.5 py-1.5 text-xs font-medium rounded-lg border border-sky-200/25 bg-white/10 hover:bg-white/20 text-white transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0"
            >
              <Database className="w-3.5 h-3.5 text-sky-200" />
              <span className="hidden sm:inline">PHP Source</span>
            </button>

            <button
              onClick={onOpenAdmin}
              title="Open School Administration Records"
              className="px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-white text-[#0B1F3A] hover:bg-sky-100 transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-[#0B1F3A]" />
              <span className="hidden sm:inline">{t.adminPortal}</span>
              <span className="text-[11px] font-mono tabular-nums text-[#1A4073]">
                ({studentCount})
              </span>
            </button>

            <button
              onClick={onToggleLang}
              className="px-2.5 py-1.5 text-xs font-semibold rounded-lg border border-sky-200/25 text-sky-100 hover:bg-white/15 transition-colors whitespace-nowrap shrink-0"
              title={lang === 'en' ? 'Switch to Kinyarwanda' : 'Switch to English'}
            >
              {lang === 'en' ? 'RW' : 'EN'}
            </button>

            <button
              onClick={onToggleTheme}
              className="p-1.5 rounded-lg border border-sky-200/25 text-sky-100 hover:bg-white/15 transition-colors shrink-0"
              title={theme === 'light' ? 'Switch to Dark Mode' : 'Switch to Light Mode'}
              aria-label="Toggle theme"
            >
              {theme === 'light' ? (
                <Moon className="w-4 h-4" />
              ) : (
                <Sun className="w-4 h-4" />
              )}
            </button>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-1.5 text-white hover:text-sky-200 shrink-0"
              aria-label="Open navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#0B1F3A] border-t border-sky-200/20 px-4 pt-3 pb-5 space-y-1.5">
          <a
            href="#home"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3 py-2 text-sm font-medium rounded-lg hover:bg-white/10 text-white"
          >
            {t.home}
          </a>
          <a
            href="#programs"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3 py-2 text-sm font-medium rounded-lg hover:bg-white/10 text-white"
          >
            {t.programs}
          </a>
          <a
            href="#fees"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3 py-2 text-sm font-medium rounded-lg hover:bg-white/10 text-white"
          >
            {t.fees}
          </a>
          <a
            href="#register"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3 py-2 text-sm font-medium rounded-lg hover:bg-white/10 text-white"
          >
            {t.register}
          </a>
          <a
            href="#contact"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3 py-2 text-sm font-medium rounded-lg hover:bg-white/10 text-white"
          >
            {t.contact}
          </a>
          <div className="pt-3 mt-2 border-t border-sky-200/20 flex flex-col gap-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenDownload();
              }}
              className="w-full py-2 text-xs font-semibold border border-sky-200/30 bg-white/10 text-white rounded-lg text-center flex items-center justify-center gap-1.5"
            >
              <Download className="w-4 h-4" />
              Export Project (.ZIP)
            </button>
            <div className="flex gap-2">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenPhpCenter();
                }}
                className="flex-1 py-2 text-xs font-semibold border border-sky-200/30 text-sky-100 rounded-lg text-center"
              >
                PHP Source
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenAdmin();
                }}
                className="flex-1 py-2 text-xs font-semibold bg-white text-[#0B1F3A] rounded-lg text-center"
              >
                {t.adminPortal} ({studentCount})
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
