import React, { useState, useEffect } from 'react';
import { Language, ProgramId, StudentRegistration } from '../types/index.ts';
import { T } from '../data/translations.ts';
import { PROGRAMS } from '../data/programsData.ts';
import { storageService } from '../services/storageService.ts';
import { CheckCircle2, MessageSquare, Mail, Printer, Database, ClipboardCheck } from 'lucide-react';

interface RegistrationSectionProps {
  lang: Language;
  selectedProgram: ProgramId;
  onRegistrationComplete: (reg: StudentRegistration) => void;
  onOpenPhpCenter: () => void;
}

const SCHOOL_WHATSAPP = '250788123456';
const SCHOOL_EMAIL = 'admissions@saintmichael.rw';

export const RegistrationSection: React.FC<RegistrationSectionProps> = ({
  lang,
  selectedProgram,
  onRegistrationComplete,
  onOpenPhpCenter
}) => {
  const t = T[lang];

  // Form Fields
  const [name, setName] = useState('');
  const [dob, setDob] = useState('2007-05-15');
  const [district, setDistrict] = useState('');
  const [school, setSchool] = useState('');
  const [prog, setProg] = useState<ProgramId>(selectedProgram);
  const [parent, setParent] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [msg, setMsg] = useState('');

  // Update program if prop changes
  useEffect(() => {
    setProg(selectedProgram);
  }, [selectedProgram]);

  // Saved Registration Result
  const [lastSaved, setLastSaved] = useState<StudentRegistration | null>(null);
  const [showSqlBreakdown, setShowSqlBreakdown] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !dob || !district.trim() || !parent.trim() || !phone.trim()) return;

    const saved = storageService.saveRegistration({
      name: name.trim(),
      dob,
      district: district.trim(),
      school: school.trim(),
      prog,
      parent: parent.trim(),
      phone: phone.trim(),
      email: email.trim() || undefined,
      msg: msg.trim() || undefined
    });

    setLastSaved(saved);
    onRegistrationComplete(saved);
  };

  const getFormattedSummary = (reg: StudentRegistration) => {
    const selectedProgObj = PROGRAMS.find(p => p.id === reg.prog);
    const progTitle = selectedProgObj ? t[selectedProgObj.id] : reg.prog;

    return [
      `*** ${t.regT} - Saint Michael Technical High School ***`,
      `${t.regCodeLabel}: ${reg.regCode}`,
      `${t.rName}: ${reg.name}`,
      `${t.rDob}: ${reg.dob}`,
      `${t.rDistrict}: ${reg.district}`,
      `${t.rSchool}: ${reg.school || 'N/A'}`,
      `${t.fprog}: ${progTitle}`,
      `${t.rParent}: ${reg.parent}`,
      `${t.rPhone}: ${reg.phone}`,
      `${t.rEmail}: ${reg.email || 'N/A'}`,
      `${t.rMsg}: ${reg.msg || 'N/A'}`,
      `Date: ${new Date(reg.createdAt).toLocaleDateString()}`
    ].join('\n');
  };

  const inputClass =
    'w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-sky-200/20 bg-[#F8FAFC] dark:bg-[#061121] text-[#0B1F3A] dark:text-white focus:outline-none focus:border-[#0B1F3A] dark:focus:border-sky-300';

  return (
    <section id="register" className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      
      {/* Header with light hairline rule */}
      <div className="text-left mb-10 pb-6 border-b border-slate-200 dark:border-sky-200/15">
        <div className="flex items-center gap-3 mb-2">
          <span className="h-px w-8 bg-[#0B1F3A] dark:bg-sky-300" aria-hidden="true" />
          <span className="text-xs font-semibold tracking-wider uppercase text-[#1A4073] dark:text-sky-300">
            Admissions &amp; Enrollment
          </span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-cinzel font-bold text-[#0B1F3A] dark:text-white text-balance">
          {t.regT}
        </h2>
        <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 mt-2 max-w-3xl leading-relaxed">
          {t.regIntro}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Registration Form (7 columns) */}
        <div className="lg:col-span-7">
          <div className="bg-white dark:bg-[#0B1D38] rounded-xl border border-slate-200 dark:border-sky-200/15 p-6 sm:p-8 shadow-sm text-left">
            
            <form onSubmit={handleSubmit} className="space-y-4 text-xs sm:text-sm">
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-[#0B1F3A] dark:text-slate-200 mb-1.5">
                    {t.rName} <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Mugisha Emmanuel"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className={inputClass}
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#0B1F3A] dark:text-slate-200 mb-1.5">
                    {t.rDob} <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={dob}
                    onChange={(e) => setDob(e.target.value)}
                    className={inputClass}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-[#0B1F3A] dark:text-slate-200 mb-1.5">
                    {t.rDistrict} <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Gasabo, Kigali"
                    value={district}
                    onChange={(e) => setDistrict(e.target.value)}
                    className={inputClass}
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#0B1F3A] dark:text-slate-200 mb-1.5">
                    {t.rSchool}
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. GS Remera Protestant"
                    value={school}
                    onChange={(e) => setSchool(e.target.value)}
                    className={inputClass}
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-[#0B1F3A] dark:text-slate-200 mb-1.5">
                  {t.fprog} (Technical Trade) <span className="text-red-500">*</span>
                </label>
                <select
                  required
                  value={prog}
                  onChange={(e) => setProg(e.target.value as ProgramId)}
                  className={`${inputClass} font-medium`}
                >
                  {PROGRAMS.map((p) => (
                    <option key={p.id} value={p.id}>
                      {t[p.id]} - {p.duration}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-[#0B1F3A] dark:text-slate-200 mb-1.5">
                    {t.rParent} <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Habimana Jean Bosco"
                    value={parent}
                    onChange={(e) => setParent(e.target.value)}
                    className={inputClass}
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#0B1F3A] dark:text-slate-200 mb-1.5">
                    {t.rPhone} <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="0788123456"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className={inputClass}
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-[#0B1F3A] dark:text-slate-200 mb-1.5">
                  {t.rEmail}
                </label>
                <input
                  type="email"
                  placeholder="parent@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className={inputClass}
                />
              </div>

              <div>
                <label className="block font-semibold text-[#0B1F3A] dark:text-slate-200 mb-1.5">
                  {t.rMsg}
                </label>
                <textarea
                  rows={3}
                  placeholder="Any prior experience, special dietary or technical interests..."
                  value={msg}
                  onChange={(e) => setMsg(e.target.value)}
                  className={inputClass}
                />
              </div>

              <button
                type="submit"
                className="w-full py-3.5 px-4 rounded-lg font-semibold bg-[#0B1F3A] text-white hover:bg-[#163868] dark:bg-sky-200 dark:text-[#0B1F3A] dark:hover:bg-white transition-colors shadow-sm text-sm sm:text-base flex items-center justify-center gap-2"
              >
                <CheckCircle2 className="w-5 h-5" />
                {t.rSubmit}
              </button>

            </form>

          </div>
        </div>

        {/* Output & Receipt Slip (5 columns) */}
        <div className="lg:col-span-5 space-y-4">
          
          {lastSaved ? (
            <div id="print-receipt" className="bg-white dark:bg-[#0B1D38] rounded-xl border border-[#0B1F3A]/30 dark:border-sky-200/30 p-6 shadow-md text-left">
              
              <div className="flex items-center justify-between border-b border-slate-200 dark:border-sky-200/15 pb-3.5 mb-4">
                <div>
                  <span className="text-[10px] font-mono uppercase tracking-widest text-[#1A4073] dark:text-sky-300 font-semibold block">
                    Official Admission Slip
                  </span>
                  <h4 className="font-cinzel text-lg font-bold text-[#0B1F3A] dark:text-white">
                    Saint Michael THS
                  </h4>
                </div>
                <div className="bg-[#0B1F3A] text-white dark:bg-sky-200 dark:text-[#0B1F3A] text-xs font-mono font-bold px-2.5 py-1 rounded">
                  {lastSaved.regCode}
                </div>
              </div>

              <div className="space-y-2.5 text-xs">
                <p className="text-slate-700 dark:text-slate-300 font-medium">
                  {t.rReady}
                </p>

                <div className="bg-[#F8FAFC] dark:bg-[#061121] p-4 rounded-lg border border-slate-200 dark:border-sky-200/15 font-mono text-[11px] sm:text-xs text-slate-800 dark:text-slate-200 whitespace-pre-wrap leading-relaxed">
                  {getFormattedSummary(lastSaved)}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2">
                  <a
                    target="_blank"
                    rel="noopener noreferrer"
                    href={`https://wa.me/${SCHOOL_WHATSAPP}?text=${encodeURIComponent(getFormattedSummary(lastSaved))}`}
                    className="py-2.5 px-3 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold rounded-lg text-xs text-center flex items-center justify-center gap-1.5"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    {t.rWA}
                  </a>

                  <a
                    href={`mailto:${SCHOOL_EMAIL}?subject=${encodeURIComponent(`${t.regT} - ${lastSaved.name} (${lastSaved.regCode})`)}&body=${encodeURIComponent(getFormattedSummary(lastSaved))}`}
                    className="py-2.5 px-3 bg-[#0B1F3A] hover:bg-[#163868] text-white dark:bg-sky-200 dark:text-[#0B1F3A] dark:hover:bg-white font-semibold rounded-lg text-xs text-center flex items-center justify-center gap-1.5"
                  >
                    <Mail className="w-3.5 h-3.5" />
                    {t.rMail}
                  </a>
                </div>

                <button
                  type="button"
                  onClick={() => window.print()}
                  className="w-full mt-2 py-2 border border-slate-300 dark:border-sky-200/25 text-[#0B1F3A] dark:text-sky-200 font-semibold rounded-lg text-xs hover:bg-[#0B1F3A] hover:text-white dark:hover:bg-sky-200 dark:hover:text-[#0B1F3A] transition-colors flex items-center justify-center gap-1.5"
                >
                  <Printer className="w-3.5 h-3.5" />
                  {t.rPrint}
                </button>

                <p className="text-[11px] text-slate-500 dark:text-slate-400 pt-1 italic">
                  {t.rNext}
                </p>
              </div>

              {/* PHP & SQL Technical Insight Toggle */}
              <div className="mt-4 pt-3 border-t border-slate-200 dark:border-sky-200/15">
                <button
                  type="button"
                  onClick={() => setShowSqlBreakdown(!showSqlBreakdown)}
                  className="w-full text-left text-xs font-semibold text-[#0B1F3A] dark:text-sky-200 flex items-center justify-between"
                >
                  <span className="flex items-center gap-1.5">
                    <Database className="w-3.5 h-3.5" /> How PHP &amp; MySQL saved this
                  </span>
                  <span className="underline text-[11px]">{showSqlBreakdown ? 'Hide' : 'Inspect'}</span>
                </button>

                {showSqlBreakdown && (
                  <div className="mt-2 p-3 bg-[#061121] text-slate-200 rounded-lg border border-sky-200/15 font-mono text-[10px] space-y-2 overflow-x-auto">
                    <div>
                      <span className="text-sky-300">1. Received $_POST payload in register.php:</span>
                      <pre>{JSON.stringify({ name: lastSaved.name, dob: lastSaved.dob, district: lastSaved.district, prog: lastSaved.prog, phone: lastSaved.phone }, null, 2)}</pre>
                    </div>
                    <div>
                      <span className="text-amber-300">2. Executed Prepared PDO SQL:</span>
                      <pre>INSERT INTO registrations (reg_code, full_name, dob, district, program_id, parent_phone) VALUES ('{lastSaved.regCode}', '{lastSaved.name}', '{lastSaved.dob}', '{lastSaved.district}', '{lastSaved.prog}', '{lastSaved.phone}');</pre>
                    </div>
                    <div className="pt-1">
                      <button
                        type="button"
                        onClick={onOpenPhpCenter}
                        className="text-sky-300 underline hover:text-white"
                      >
                        View Full register.php Source Code &rarr;
                      </button>
                    </div>
                  </div>
                )}
              </div>

            </div>
          ) : (
            <div className="rounded-xl border border-slate-200 dark:border-sky-200/15 p-6 bg-white dark:bg-[#0B1D38] shadow-sm text-left space-y-3">
              <div className="flex items-center gap-2 font-semibold text-sm text-[#0B1F3A] dark:text-white pb-2.5 border-b border-slate-100 dark:border-sky-200/10">
                <ClipboardCheck className="w-4 h-4 text-[#1A4073] dark:text-sky-300" />
                <span>Instant Online Registration</span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                Fill out the form on the left to immediately register for the upcoming academic year.
              </p>
              <ul className="text-xs space-y-2 pt-1 text-slate-600 dark:text-slate-300">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#1A4073] dark:text-sky-300 flex-none" />
                  <span>Automatic student registration code generation</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#1A4073] dark:text-sky-300 flex-none" />
                  <span>Instant WhatsApp &amp; email notification link</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#1A4073] dark:text-sky-300 flex-none" />
                  <span>Ready for PHP &amp; MySQL database submission</span>
                </li>
              </ul>
            </div>
          )}

        </div>

      </div>

    </section>
  );
};
