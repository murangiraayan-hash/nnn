import React, { useState } from 'react';
import { Language } from '../types/index.ts';
import { T } from '../data/translations.ts';
import { Phone, Mail, MapPin, Clock, Send, CheckCircle2 } from 'lucide-react';

interface ContactSectionProps {
  lang: Language;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ lang }) => {
  const t = T[lang];
  const [inquiryName, setInquiryName] = useState('');
  const [inquiryPhone, setInquiryPhone] = useState('');
  const [inquiryMsg, setInquiryMsg] = useState('');
  const [sent, setSent] = useState(false);

  const handleInquirySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inquiryName.trim() || !inquiryPhone.trim()) return;
    setSent(true);
    setTimeout(() => {
      setInquiryName('');
      setInquiryPhone('');
      setInquiryMsg('');
      setSent(false);
    }, 4000);
  };

  const inputClass =
    'w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-sky-200/20 bg-[#F8FAFC] dark:bg-[#061121] text-[#0B1F3A] dark:text-white focus:outline-none focus:border-[#0B1F3A] dark:focus:border-sky-300';

  return (
    <section id="contact" className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      
      {/* Header with light hairline rule */}
      <div className="text-left mb-10 pb-6 border-b border-slate-200 dark:border-sky-200/15">
        <div className="flex items-center gap-3 mb-2">
          <span className="h-px w-8 bg-[#0B1F3A] dark:bg-sky-300" aria-hidden="true" />
          <span className="text-xs font-semibold tracking-wider uppercase text-[#1A4073] dark:text-sky-300">
            Admissions Hotline &amp; Campus Office
          </span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-cinzel font-bold text-[#0B1F3A] dark:text-white text-balance">
          {t.contact}
        </h2>
        <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 mt-2 max-w-3xl leading-relaxed">
          {lang === 'en'
            ? 'Have questions about programs, fees, or boarding facilities? Reach out to our admissions team directly.'
            : 'Ufite ikibazo cyerekeye amashami, amafaranga y\'ishuri cyangwa kwiyandikisha? Twandikire cyangwa udusize ubutumwa.'}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start text-left">
        
        {/* Contact Info List (5 columns) */}
        <div className="lg:col-span-5 rounded-xl bg-white dark:bg-[#0B1D38] border border-slate-200 dark:border-sky-200/15 shadow-sm divide-y divide-slate-200/80 dark:divide-sky-200/10">
          
          <div className="p-5 flex items-start gap-4">
            <div className="w-10 h-10 rounded-lg bg-[#F1F5F9] dark:bg-[#112D53] border border-slate-200 dark:border-sky-200/15 text-[#0B1F3A] dark:text-sky-200 flex items-center justify-center flex-none">
              <MapPin className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-semibold text-sm text-[#0B1F3A] dark:text-white">
                Campus Location
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                Saint Michael Technical High School<br />
                Kigali, Rwanda (Near Technical &amp; TVET Education Hub)<br />
                P.O. Box 4210 Kigali
              </p>
            </div>
          </div>

          <div className="p-5 flex items-start gap-4">
            <div className="w-10 h-10 rounded-lg bg-[#F1F5F9] dark:bg-[#112D53] border border-slate-200 dark:border-sky-200/15 text-[#0B1F3A] dark:text-sky-200 flex items-center justify-center flex-none">
              <Phone className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-semibold text-sm text-[#0B1F3A] dark:text-white">
                Direct Telephones
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 font-mono tabular-nums leading-relaxed">
                Admissions: +250 788 123 456<br />
                Administration: +250 788 654 321<br />
                MTN MoMo Hotline: *182*8*1*054321#
              </p>
            </div>
          </div>

          <div className="p-5 flex items-start gap-4">
            <div className="w-10 h-10 rounded-lg bg-[#F1F5F9] dark:bg-[#112D53] border border-slate-200 dark:border-sky-200/15 text-[#0B1F3A] dark:text-sky-200 flex items-center justify-center flex-none">
              <Mail className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-semibold text-sm text-[#0B1F3A] dark:text-white">
                Official Inquiries
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 font-mono leading-relaxed">
                Email: info@saintmichael.rw<br />
                Admissions: admissions@saintmichael.rw
              </p>
            </div>
          </div>

          <div className="p-5 flex items-start gap-4 bg-[#F8FAFC]/70 dark:bg-[#061121]/40 rounded-b-xl">
            <div className="w-10 h-10 rounded-lg bg-[#F1F5F9] dark:bg-[#112D53] border border-slate-200 dark:border-sky-200/15 text-[#0B1F3A] dark:text-sky-200 flex items-center justify-center flex-none">
              <Clock className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-semibold text-sm text-[#0B1F3A] dark:text-white">
                Office &amp; Visiting Hours
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                Monday – Friday: 07:30 AM – 05:00 PM<br />
                Saturday: 08:30 AM – 01:00 PM (Admissions Desk Open)<br />
                Sunday: Closed
              </p>
            </div>
          </div>

        </div>

        {/* Quick Inquiry Form (7 columns) */}
        <div className="lg:col-span-7">
          <div className="p-6 sm:p-8 rounded-xl bg-white dark:bg-[#0B1D38] border border-slate-200 dark:border-sky-200/15 shadow-sm">
            <h3 className="font-cinzel text-xl font-bold text-[#0B1F3A] dark:text-white mb-1">
              {lang === 'en' ? 'Send a Direct Message' : 'Ohereza Ubutumwa'}
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 pb-4 mb-5 border-b border-slate-100 dark:border-sky-200/10">
              {lang === 'en'
                ? 'Leave your phone number or question and our admissions registrar will contact you within 24 hours.'
                : 'Uzuza imyirondoro yawe n\'ikibazo ufite, umwanditsi mukuru w\'ishuri azagusubiza vuba.'}
            </p>

            <form onSubmit={handleInquirySubmit} className="space-y-4 text-xs sm:text-sm">
              <div>
                <label className="block font-semibold text-[#0B1F3A] dark:text-slate-200 mb-1.5">
                  {t.fname}
                </label>
                <input
                  type="text"
                  required
                  placeholder="Your Name"
                  value={inquiryName}
                  onChange={(e) => setInquiryName(e.target.value)}
                  className={inputClass}
                />
              </div>

              <div>
                <label className="block font-semibold text-[#0B1F3A] dark:text-slate-200 mb-1.5">
                  {t.fphone}
                </label>
                <input
                  type="tel"
                  required
                  placeholder="0788XXXXXX"
                  value={inquiryPhone}
                  onChange={(e) => setInquiryPhone(e.target.value)}
                  className={inputClass}
                />
              </div>

              <div>
                <label className="block font-semibold text-[#0B1F3A] dark:text-slate-200 mb-1.5">
                  {t.rMsg}
                </label>
                <textarea
                  rows={4}
                  required
                  placeholder="Ask about boarding, intake dates, scholarship assistance, or program requirements..."
                  value={inquiryMsg}
                  onChange={(e) => setInquiryMsg(e.target.value)}
                  className={inputClass}
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 px-4 rounded-lg font-semibold bg-[#0B1F3A] text-white hover:bg-[#163868] dark:bg-sky-200 dark:text-[#0B1F3A] dark:hover:bg-white transition-colors shadow-sm text-sm flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                {lang === 'en' ? 'Send Inquiry Message' : 'Ohereza Ubutumwa'}
              </button>

              {sent && (
                <div className="p-3 bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-600/30 text-emerald-800 dark:text-emerald-200 rounded-lg text-xs font-medium flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-none" />
                  <span>Your message has been sent successfully. An admissions counselor will call you shortly.</span>
                </div>
              )}
            </form>
          </div>
        </div>

      </div>

    </section>
  );
};
