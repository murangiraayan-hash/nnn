import React from 'react';
import { Language } from '../types/index.ts';
import { T } from '../data/translations.ts';
import { Database, ShieldCheck } from 'lucide-react';

interface FooterProps {
  lang: Language;
  onOpenPhpCenter: () => void;
  onOpenAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({ lang, onOpenPhpCenter, onOpenAdmin }) => {
  const t = T[lang];

  return (
    <footer className="bg-[#0B1F3A] text-white border-t border-sky-200/20 pt-12 pb-8 px-4 sm:px-6 lg:px-8 mt-12">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 text-left pb-10 border-b border-sky-200/15">
        
        {/* Brand & Motto (5 cols) */}
        <div className="md:col-span-5 space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-white/10 border border-sky-200/30 text-sky-100 flex items-center justify-center font-cinzel font-bold text-lg">
              SM
            </div>
            <div>
              <span className="font-cinzel font-bold text-base text-white block">
                Saint Michael
              </span>
              <span className="text-xs uppercase tracking-widest text-sky-200/90 font-semibold">
                Technical High School
              </span>
            </div>
          </div>
          <p className="text-xs text-slate-300 max-w-sm leading-relaxed">
            {t.tagline}
          </p>
          <div className="text-xs font-mono text-sky-200/90 pt-1">
            <span>RTQF Level 3-5 Accredited</span>
            <span className="mx-2 text-sky-200/40" aria-hidden="true">·</span>
            <span>TVET Rwanda</span>
          </div>
        </div>

        {/* Quick Links (3 cols) */}
        <div className="md:col-span-3 space-y-2 text-xs">
          <h4 className="font-semibold text-xs text-sky-200 uppercase tracking-wider mb-3">
            Navigation
          </h4>
          <ul className="space-y-2 text-slate-200">
            <li><a href="#home" className="hover:text-white hover:underline transition-colors">{t.home}</a></li>
            <li><a href="#programs" className="hover:text-white hover:underline transition-colors">{t.programs}</a></li>
            <li><a href="#fees" className="hover:text-white hover:underline transition-colors">{t.fees}</a></li>
            <li><a href="#register" className="hover:text-white hover:underline transition-colors">{t.register}</a></li>
            <li><a href="#contact" className="hover:text-white hover:underline transition-colors">{t.contact}</a></li>
          </ul>
        </div>

        {/* Developer & Backend Tools (4 cols) */}
        <div className="md:col-span-4 space-y-3 text-xs">
          <h4 className="font-semibold text-xs text-sky-200 uppercase tracking-wider mb-3">
            School Administration &amp; Backend
          </h4>
          <p className="text-xs text-slate-300 leading-relaxed">
            Includes exportable MySQL schemas, standalone PHP endpoints, and school admissions management.
          </p>
          <div className="flex flex-col sm:flex-row gap-2 pt-1">
            <button
              onClick={onOpenPhpCenter}
              className="px-3.5 py-2 bg-white text-[#0B1F3A] font-semibold rounded-lg text-xs hover:bg-sky-100 transition-colors flex items-center justify-center gap-1.5"
            >
              <Database className="w-3.5 h-3.5" />
              PHP &amp; MySQL Source
            </button>
            <button
              onClick={onOpenAdmin}
              className="px-3.5 py-2 bg-white/10 text-white font-semibold rounded-lg text-xs hover:bg-white/20 transition-colors flex items-center justify-center gap-1.5 border border-sky-200/25"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-sky-200" />
              Admin Portal
            </button>
          </div>
        </div>

      </div>

      <div className="max-w-7xl mx-auto pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 gap-2">
        <p>&copy; {new Date().getFullYear()} Saint Michael Technical High School. All rights reserved.</p>
        <p>Kigali, Rwanda · Technical Education &amp; Practical Skills</p>
      </div>
    </footer>
  );
};
