import React, { useState, useRef, useEffect } from 'react';
import { Language } from '../types/index.ts';
import { T } from '../data/translations.ts';
import { Play, Pause, Award, BookOpen, Users, CheckCircle2, Video } from 'lucide-react';

interface HeroProps {
  lang: Language;
}

interface VideoClip {
  id: string;
  labelEn: string;
  labelRw: string;
  src: string;
}

const CLIPS: VideoClip[] = [
  { id: 'software', labelEn: 'Software Development Lab', labelRw: 'Icyumba cy\'Ikoranabuhanga', src: '/videos/software.mp4' },
  { id: 'school', labelEn: 'School Campus & Practical Workshops', labelRw: 'Ishuri n\'Amahugurwa Ngiro', src: '/videos/school.mp4' }
];

export const Hero: React.FC<HeroProps> = ({ lang }) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [currentClipIndex, setCurrentClipIndex] = useState(0);
  const [imgError, setImgError] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  const t = T[lang];

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.currentTime = 0;
      if (isPlaying) {
        videoRef.current.play().catch(() => {});
      }
    }
  }, [currentClipIndex]);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
        setIsPlaying(false);
      } else {
        videoRef.current.play().catch(() => {});
        setIsPlaying(true);
      }
    }
  };

  const currentClip = CLIPS[currentClipIndex];

  return (
    <section id="home" className="pt-8 pb-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      
      {/* Hero Showcase Container */}
      <div className="relative rounded-2xl overflow-hidden shadow-xl border border-sky-200/25 bg-[#0B1F3A] text-white">
        
        {/* Background Video with Navy Gradient Scrim & Subtle Light Hairline Grid */}
        <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
          <video
            ref={videoRef}
            src={currentClip.src}
            muted
            playsInline
            loop
            autoPlay
            className="w-full h-full object-cover opacity-30 scale-105 transition-opacity duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#061121] via-[#0B1F3A]/90 to-[#0B1F3A]/70" />
          <div className="absolute inset-0 bg-navy-hairline-grid" />
        </div>

        {/* Hero Content Grid */}
        <div className="relative z-10 p-6 sm:p-10 lg:p-14 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Left Text Block */}
          <div className="lg:col-span-8 text-left space-y-5">
            <div className="inline-block pb-2 border-b border-sky-300/35 text-xs font-semibold tracking-widest uppercase text-sky-200">
              {t.eyebrow}
            </div>

            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-cinzel font-bold leading-tight text-white text-balance">
              <span className="block text-lg sm:text-xl font-sans font-normal text-sky-200/90 mb-1">
                {t.welcomeTo}
              </span>
              <span className="inline-block bg-white text-[#0B1F3A] px-4 py-1 rounded-lg shadow-sm mt-1 font-extrabold tracking-wide">
                Saint Michael
              </span>
              <span className="block text-white mt-2 text-2xl sm:text-4xl lg:text-5xl">
                Technical High School
              </span>
            </h1>

            <p className="text-sm sm:text-base text-slate-200 max-w-2xl leading-relaxed">
              {t.desc}
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <a
                href="#register"
                className="px-6 py-3 bg-white text-[#0B1F3A] font-semibold text-sm rounded-lg hover:bg-sky-100 transition-colors shadow-sm whitespace-nowrap shrink-0"
              >
                {t.apply} &rarr;
              </a>
              <a
                href="#programs"
                className="px-6 py-3 bg-transparent text-white font-medium text-sm rounded-lg hover:bg-white/10 transition-colors border border-sky-200/40 whitespace-nowrap shrink-0"
              >
                {t.programs}
              </a>
              <a
                href="#fees"
                className="px-4 py-2.5 text-sky-200 hover:text-white font-medium text-sm underline underline-offset-4 whitespace-nowrap shrink-0"
              >
                {t.fees} &gt;
              </a>
            </div>

            {/* Video Controls Bar */}
            <div className="pt-4 border-t border-sky-200/15 flex flex-wrap items-center gap-3 text-xs text-sky-100">
              <button
                onClick={togglePlay}
                className="w-8 h-8 rounded-lg bg-[#061121]/80 border border-sky-200/30 text-white flex items-center justify-center hover:bg-white hover:text-[#0B1F3A] transition-colors"
                aria-label={isPlaying ? 'Pause video clip' : 'Play video clip'}
              >
                {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 ml-0.5" />}
              </button>

              <div className="flex items-center gap-2 bg-[#061121]/70 px-3 py-1.5 rounded-lg border border-sky-200/20">
                <Video className="w-3.5 h-3.5 text-sky-300" />
                <span className="font-medium text-white">
                  {lang === 'en' ? currentClip.labelEn : currentClip.labelRw}
                </span>
                <span className="text-sky-200/40" aria-hidden="true">·</span>
                <button
                  onClick={() => setCurrentClipIndex((prev) => (prev + 1) % CLIPS.length)}
                  className="text-[11px] underline text-sky-200 hover:text-white font-semibold"
                >
                  {lang === 'en' ? 'Switch clip' : 'Hindura videwo'}
                </button>
              </div>
            </div>
          </div>

          {/* Right Image Block: Archangel Saint Michael Crest */}
          <div className="lg:col-span-4 flex flex-col items-center justify-center">
            <div className="bg-[#061121]/80 p-3 rounded-xl border border-sky-200/30 shadow-xl">
              {!imgError ? (
                <img
                  src="/images/saint-michael.jpg"
                  alt="Saint Michael the Archangel - Patron of Saint Michael Technical High School"
                  referrerPolicy="no-referrer"
                  onError={() => setImgError(true)}
                  className="w-48 sm:w-56 lg:w-64 h-auto rounded-lg object-cover border border-sky-200/20"
                />
              ) : (
                <div className="w-48 sm:w-56 lg:w-64 aspect-[3/4] rounded-lg bg-[#112D53] border border-sky-200/25 flex flex-col items-center justify-center p-4 text-center">
                  <Award className="w-10 h-10 text-sky-200 mb-2" />
                  <span className="font-cinzel font-bold text-sm text-white">Saint Michael THS</span>
                </div>
              )}
              <div className="mt-2.5 pt-2 border-t border-sky-200/15 text-center">
                <span className="text-[11px] font-semibold tracking-wider uppercase text-sky-200 block">
                  Patron Saint &amp; Guide
                </span>
                <span className="text-[11px] text-slate-300 italic">
                  Quis ut Deus? (Who is like God?)
                </span>
              </div>
            </div>
          </div>

        </div>

        {/* Feature Highlights Banner with light small hairline dividers */}
        <div className="relative z-10 border-t border-sky-200/20 bg-[#061121]/60 backdrop-blur-sm grid grid-cols-2 md:grid-cols-4 divide-y md:divide-y-0 md:divide-x divide-sky-200/15 text-center">
          <div className="flex items-center justify-center gap-2 px-4 py-3.5">
            <Award className="w-4 h-4 text-sky-300 shrink-0" />
            <span className="text-xs sm:text-sm font-medium text-slate-100">RTQF Level 3-5 TVET</span>
          </div>
          <div className="flex items-center justify-center gap-2 px-4 py-3.5">
            <BookOpen className="w-4 h-4 text-sky-300 shrink-0" />
            <span className="text-xs sm:text-sm font-medium text-slate-100">5 Technical Programs</span>
          </div>
          <div className="flex items-center justify-center gap-2 px-4 py-3.5">
            <CheckCircle2 className="w-4 h-4 text-sky-300 shrink-0" />
            <span className="text-xs sm:text-sm font-medium text-slate-100">Modern Hands-on Labs</span>
          </div>
          <div className="flex items-center justify-center gap-2 px-4 py-3.5">
            <Users className="w-4 h-4 text-sky-300 shrink-0" />
            <span className="text-xs sm:text-sm font-medium text-slate-100">Career Internship Support</span>
          </div>
        </div>

      </div>

    </section>
  );
};
