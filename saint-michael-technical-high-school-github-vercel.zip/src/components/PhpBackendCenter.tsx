import React, { useState } from 'react';
import { PHP_FILES } from '../data/phpCodeData.ts';
import { PhpFile } from '../types/index.ts';
import { generateFullProjectZip } from '../services/zipExportService.ts';
import { 
  X, 
  Copy, 
  Check, 
  Download, 
  Database, 
  FileCode, 
  Server, 
  Play, 
  BookOpen, 
  Terminal,
  CheckCircle2
} from 'lucide-react';

interface PhpBackendCenterProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenDownloadModal?: () => void;
}

export const PhpBackendCenter: React.FC<PhpBackendCenterProps> = ({ isOpen, onClose }) => {
  const [activeFileIndex, setActiveFileIndex] = useState(0);
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'code' | 'simulator' | 'guide'>('code');

  // Simulator State
  const [simName, setSimName] = useState('Uwimana Claudine');
  const [simProg, setSimProg] = useState('p1');
  const [simPhone, setSimPhone] = useState('0788776655');
  const [simResult, setSimResult] = useState<{
    httpStatus: number;
    phpVariables: any;
    executedSql: string;
    jsonResponse: any;
  } | null>(null);

  if (!isOpen) return null;

  const currentFile: PhpFile = PHP_FILES[activeFileIndex];

  const handleCopy = () => {
    navigator.clipboard.writeText(currentFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadCurrent = () => {
    const blob = new Blob([currentFile.code], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = currentFile.filename;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadAll = async () => {
    try {
      const zipBlob = await generateFullProjectZip();
      const url = URL.createObjectURL(zipBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'Saint_Michael_Technical_High_School_Full_Project.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error(e);
    }
  };

  const handleRunSimulator = () => {
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const regCode = `SMTHS-2025-${randomSuffix}`;

    setSimResult({
      httpStatus: 201,
      phpVariables: {
        '$_SERVER["REQUEST_METHOD"]': 'POST',
        '$_POST["name"]': simName,
        '$_POST["prog"]': simProg,
        '$_POST["phone"]': simPhone,
        '$regCode': regCode,
        '$pdo': 'PDO Object (Connected to smths_school_db on localhost)'
      },
      executedSql: `INSERT INTO registrations (reg_code, full_name, dob, district, program_id, parent_phone, status)\nVALUES ('${regCode}', '${simName}', '2007-08-20', 'Gasabo, Kigali', '${simProg}', '${simPhone}', 'pending');`,
      jsonResponse: {
        success: true,
        message: 'Registration successfully saved in the database!',
        registration_id: 42,
        reg_code: regCode,
        student_name: simName,
        program: simProg,
        status: 'pending',
        timestamp: new Date().toISOString()
      }
    });
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4">
      <div className="bg-[#F8FAFC] dark:bg-[#061121] text-[#0B1F3A] dark:text-slate-100 w-full max-w-5xl rounded-2xl border border-slate-300 dark:border-sky-200/20 shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Modal Header */}
        <div className="bg-[#0B1F3A] text-white p-4 sm:p-5 flex items-center justify-between border-b border-sky-200/20">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-white/10 border border-sky-200/25 text-sky-200 flex items-center justify-center">
              <Database className="w-5 h-5" />
            </div>
            <div className="text-left">
              <h2 className="text-base sm:text-lg font-cinzel font-bold text-white">
                PHP &amp; MySQL Backend Integration Center
              </h2>
              <p className="text-xs text-sky-200/80">
                Production-ready PHP 8 + PDO scripts, database schema &amp; XAMPP guide for school submission
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadAll}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-white text-[#0B1F3A] rounded-lg text-xs font-semibold hover:bg-sky-100 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              Download All Files
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg hover:bg-white/15 text-white transition-colors"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* View Mode Switcher */}
        <div className="bg-[#F1F5F9] dark:bg-[#08172B] px-4 sm:px-6 py-2.5 border-b border-slate-200 dark:border-sky-200/15 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-1 p-1 bg-white dark:bg-[#061121] rounded-lg border border-slate-200 dark:border-sky-200/15 text-xs font-semibold">
            <button
              onClick={() => setActiveTab('code')}
              className={`px-3 py-1.5 rounded-md transition-colors flex items-center gap-1.5 ${
                activeTab === 'code'
                  ? 'bg-[#0B1F3A] text-white dark:bg-sky-200 dark:text-[#0B1F3A]'
                  : 'text-slate-600 dark:text-slate-300 hover:text-[#0B1F3A] dark:hover:text-white'
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              PHP Source Files ({PHP_FILES.length})
            </button>
            <button
              onClick={() => setActiveTab('simulator')}
              className={`px-3 py-1.5 rounded-md transition-colors flex items-center gap-1.5 ${
                activeTab === 'simulator'
                  ? 'bg-[#0B1F3A] text-white dark:bg-sky-200 dark:text-[#0B1F3A]'
                  : 'text-slate-600 dark:text-slate-300 hover:text-[#0B1F3A] dark:hover:text-white'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              Live PHP Simulator
            </button>
            <button
              onClick={() => setActiveTab('guide')}
              className={`px-3 py-1.5 rounded-md transition-colors flex items-center gap-1.5 ${
                activeTab === 'guide'
                  ? 'bg-[#0B1F3A] text-white dark:bg-sky-200 dark:text-[#0B1F3A]'
                  : 'text-slate-600 dark:text-slate-300 hover:text-[#0B1F3A] dark:hover:text-white'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              XAMPP Tutorial
            </button>
          </div>

          <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
            Database: <b className="text-[#0B1F3A] dark:text-sky-200">smths_school_db</b>
          </div>
        </div>

        {/* Tab 1: Source Files Viewer */}
        {activeTab === 'code' && (
          <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
            
            {/* Left Files List */}
            <div className="w-full md:w-64 bg-white dark:bg-[#0B1D38] p-3 border-r border-slate-200 dark:border-sky-200/15 overflow-y-auto space-y-1">
              <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 block px-2 mb-1">
                Project Files
              </span>
              {PHP_FILES.map((f, i) => (
                <button
                  key={f.filename}
                  onClick={() => setActiveFileIndex(i)}
                  className={`w-full text-left px-3 py-2 rounded-lg text-xs font-mono font-medium transition-colors flex items-center justify-between ${
                    activeFileIndex === i
                      ? 'bg-[#0B1F3A] text-white dark:bg-sky-200 dark:text-[#0B1F3A] font-semibold'
                      : 'hover:bg-slate-100 dark:hover:bg-[#112D53]/60 text-slate-700 dark:text-slate-200'
                  }`}
                >
                  <span className="truncate">{f.filename}</span>
                  <span className="text-[9px] uppercase opacity-75 ml-1">{f.language}</span>
                </button>
              ))}
            </div>

            {/* Right Code Display */}
            <div className="flex-1 flex flex-col bg-[#061121] text-slate-100 overflow-hidden">
              
              {/* File Info Bar */}
              <div className="bg-[#0B1D38] px-4 py-2.5 border-b border-sky-200/15 flex items-center justify-between text-xs">
                <div>
                  <span className="font-mono font-bold text-sky-300">{currentFile.filename}</span>
                  <span className="text-slate-400 text-[11px] ml-2 hidden sm:inline">{currentFile.description}</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopy}
                    className="px-2.5 py-1 bg-[#112D53] hover:bg-[#1A4073] text-slate-200 rounded border border-sky-200/15 font-mono text-[11px] flex items-center gap-1 transition-colors"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-sky-300" /> : <Copy className="w-3.5 h-3.5" />}
                    {copied ? 'Copied' : 'Copy'}
                  </button>
                  <button
                    onClick={handleDownloadCurrent}
                    className="px-2.5 py-1 bg-[#112D53] hover:bg-[#1A4073] text-slate-200 rounded border border-sky-200/15 font-mono text-[11px] flex items-center gap-1 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Download
                  </button>
                </div>
              </div>

              {/* Code Editor Content */}
              <div className="flex-1 overflow-auto p-4 font-mono text-xs leading-relaxed selection:bg-sky-300 selection:text-[#0B1F3A]">
                <pre className="text-slate-200 whitespace-pre">
                  <code>{currentFile.code}</code>
                </pre>
              </div>

            </div>

          </div>
        )}

        {/* Tab 2: Live PHP Execution Simulator */}
        {activeTab === 'simulator' && (
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 text-left">
            
            <div className="p-5 rounded-xl bg-white dark:bg-[#0B1D38] border border-slate-200 dark:border-sky-200/15 shadow-sm">
              <h3 className="font-semibold text-sm text-[#0B1F3A] dark:text-white mb-1 flex items-center gap-2">
                <Play className="w-4 h-4 text-[#1A4073] dark:text-sky-300" />
                Test PHP Backend Execution (Simulated POST Request)
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-300 mb-4">
                Enter student details below and click &quot;Simulate PHP Execution&quot;. You will see how PHP parses the request, prepares the PDO SQL statement, and returns the JSON payload.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4 text-xs">
                <div>
                  <label className="block font-semibold mb-1 text-[#0B1F3A] dark:text-slate-200">Student Full Name</label>
                  <input
                    type="text"
                    value={simName}
                    onChange={(e) => setSimName(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-sky-200/20 bg-[#F8FAFC] dark:bg-[#061121] text-current"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1 text-[#0B1F3A] dark:text-slate-200">Trade / Program</label>
                  <select
                    value={simProg}
                    onChange={(e) => setSimProg(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-sky-200/20 bg-[#F8FAFC] dark:bg-[#061121] text-current"
                  >
                    <option value="p1">Software Development (p1)</option>
                    <option value="p2">Food and Beverage (p2)</option>
                    <option value="p3">Computer Systems (p3)</option>
                    <option value="p4">Architecture (p4)</option>
                    <option value="p5">Multimedia (p5)</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold mb-1 text-[#0B1F3A] dark:text-slate-200">Parent Phone</label>
                  <input
                    type="text"
                    value={simPhone}
                    onChange={(e) => setSimPhone(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-sky-200/20 bg-[#F8FAFC] dark:bg-[#061121] text-current"
                  />
                </div>
              </div>

              <button
                type="button"
                onClick={handleRunSimulator}
                className="px-5 py-2.5 bg-[#0B1F3A] text-white dark:bg-sky-200 dark:text-[#0B1F3A] rounded-lg font-semibold text-xs hover:bg-[#163868] dark:hover:bg-white flex items-center gap-2 transition-colors"
              >
                <Terminal className="w-4 h-4" />
                Simulate PHP Execution
              </button>
            </div>

            {simResult && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  
                  {/* Step 1 */}
                  <div className="bg-[#061121] text-slate-200 p-4 rounded-xl border border-sky-200/20 font-mono text-xs">
                    <div className="text-sky-300 font-semibold mb-2 flex items-center gap-1.5">
                      <Server className="w-3.5 h-3.5" />
                      Step 1: PHP Server $_POST &amp; Variables
                    </div>
                    <pre className="text-[11px] overflow-x-auto text-slate-300">
                      {JSON.stringify(simResult.phpVariables, null, 2)}
                    </pre>
                  </div>

                  {/* Step 2 */}
                  <div className="bg-[#061121] text-slate-200 p-4 rounded-xl border border-sky-200/20 font-mono text-xs">
                    <div className="text-amber-300 font-semibold mb-2 flex items-center gap-1.5">
                      <Database className="w-3.5 h-3.5" />
                      Step 2: MySQL Query Executed
                    </div>
                    <pre className="text-[11px] overflow-x-auto text-amber-200 whitespace-pre-wrap">
                      {simResult.executedSql}
                    </pre>
                  </div>

                </div>

                {/* Step 3 */}
                <div className="bg-[#061121] text-slate-200 p-4 rounded-xl border border-sky-200/20 font-mono text-xs">
                  <div className="text-sky-300 font-semibold mb-2 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-sky-300" />
                    Step 3: HTTP 201 Response returned to Browser / App
                  </div>
                  <pre className="text-[11px] overflow-x-auto text-sky-100">
                    {JSON.stringify(simResult.jsonResponse, null, 2)}
                  </pre>
                </div>
              </div>
            )}

          </div>
        )}

        {/* Tab 3: XAMPP Setup Guide */}
        {activeTab === 'guide' && (
          <div className="flex-1 overflow-y-auto p-4 sm:p-8 text-left space-y-4 leading-relaxed text-xs sm:text-sm">
            <div className="max-w-3xl mx-auto space-y-4">
              
              <div className="bg-white dark:bg-[#0B1D38] p-5 rounded-xl border border-slate-200 dark:border-sky-200/15">
                <h3 className="font-semibold text-base text-[#0B1F3A] dark:text-white mb-1">
                  How to Save Data with PHP on Your School Computer
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-300">
                  Follow these 4 simple steps to run this complete backend on your machine using XAMPP:
                </p>
              </div>

              <div className="bg-white dark:bg-[#0B1D38] rounded-xl border border-slate-200 dark:border-sky-200/15 divide-y divide-slate-200/80 dark:divide-sky-200/10">
                <div className="p-4">
                  <h4 className="font-semibold text-sm text-[#0B1F3A] dark:text-white mb-1">
                    1. Install XAMPP
                  </h4>
                  <p className="text-xs text-slate-600 dark:text-slate-300">
                    Download XAMPP from apachefriends.org. Open the XAMPP Control Panel and start <b>Apache</b> and <b>MySQL</b>.
                  </p>
                </div>

                <div className="p-4">
                  <h4 className="font-semibold text-sm text-[#0B1F3A] dark:text-white mb-1">
                    2. Copy PHP Files to htdocs
                  </h4>
                  <p className="text-xs text-slate-600 dark:text-slate-300 mb-2">
                    Click &quot;Download All Files&quot; above and place them in:
                  </p>
                  <code className="block bg-[#F1F5F9] dark:bg-[#061121] border border-slate-200 dark:border-sky-200/15 p-2 rounded text-xs font-mono text-[#0B1F3A] dark:text-sky-200">
                    C:\xampp\htdocs\smths_backend\
                  </code>
                </div>

                <div className="p-4">
                  <h4 className="font-semibold text-sm text-[#0B1F3A] dark:text-white mb-1">
                    3. Import the Database in phpMyAdmin
                  </h4>
                  <p className="text-xs text-slate-600 dark:text-slate-300">
                    Open <code className="font-mono bg-slate-100 dark:bg-[#061121] px-1 py-0.5 rounded">http://localhost/phpmyadmin</code> in your web browser. Click the <b>SQL</b> tab, copy and paste the contents of <b className="font-mono">database.sql</b>, and click <b>Go</b>.
                  </p>
                </div>

                <div className="p-4">
                  <h4 className="font-semibold text-sm text-[#0B1F3A] dark:text-white mb-1">
                    4. Open the PHP Admin Dashboard
                  </h4>
                  <p className="text-xs text-slate-600 dark:text-slate-300">
                    Visit <code className="font-mono bg-slate-100 dark:bg-[#061121] px-1 py-0.5 rounded">http://localhost/smths_backend/admin.php</code> to view all registrations, live stats, and download student reports in CSV format.
                  </p>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* Modal Footer */}
        <div className="bg-[#0B1F3A] text-sky-100 p-3 px-6 flex items-center justify-between text-xs border-t border-sky-200/20">
          <span>Saint Michael Technical High School · PHP 8 &amp; MySQL Architecture</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-white text-[#0B1F3A] font-semibold hover:bg-sky-100 transition-colors"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
