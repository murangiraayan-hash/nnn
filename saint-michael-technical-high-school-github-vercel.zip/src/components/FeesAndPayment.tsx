import React, { useState } from 'react';
import { Language, ProgramId } from '../types/index.ts';
import { T } from '../data/translations.ts';
import { FEE_SCHEDULE, PAYMENT_METHODS, PROGRAMS } from '../data/programsData.ts';
import { storageService } from '../services/storageService.ts';
import { CheckCircle, CreditCard, Building2, Printer, Check, Copy } from 'lucide-react';

interface FeesAndPaymentProps {
  lang: Language;
  onPaymentSuccess: () => void;
  defaultProgram?: ProgramId;
}

export const FeesAndPayment: React.FC<FeesAndPaymentProps> = ({
  lang,
  onPaymentSuccess,
  defaultProgram = 'p1'
}) => {
  const t = T[lang];

  // Form State
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [prog, setProg] = useState<ProgramId>(defaultProgram);
  const [method, setMethod] = useState<'momo' | 'bk' | 'bpr' | 'equity'>('momo');
  const [itemType, setItemType] = useState<'registration' | 'term_tuition' | 'uniform' | 'materials' | 'full_package'>('registration');
  const [regCode, setRegCode] = useState('');
  const [copiedCode, setCopiedCode] = useState<'momo' | 'bk' | null>(null);

  // Success Receipt State
  const [paymentResult, setPaymentResult] = useState<{
    refNumber: string;
    studentName: string;
    amount: number;
    method: string;
    itemType: string;
    createdAt: string;
  } | null>(null);

  // Calculate amount based on fee category
  const getAmountForCategory = () => {
    switch (itemType) {
      case 'registration': return 20000;
      case 'term_tuition': return 120000;
      case 'uniform': return 35000;
      case 'materials': return 25000;
      case 'full_package': return 200000;
      default: return 20000;
    }
  };

  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) return;

    const amount = getAmountForCategory();

    const record = storageService.savePayment({
      studentName: name.trim(),
      phone: phone.trim(),
      prog,
      method,
      amount,
      itemType,
      regCode: regCode.trim() || undefined
    });

    setPaymentResult({
      refNumber: record.refNumber,
      studentName: record.studentName,
      amount: record.amount,
      method: record.method,
      itemType: record.itemType,
      createdAt: record.createdAt
    });

    onPaymentSuccess();
  };

  const selectedMethodInfo = PAYMENT_METHODS[method];

  const handleCopyCode = (text: string, type: 'momo' | 'bk') => {
    navigator.clipboard.writeText(text);
    setCopiedCode(type);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  return (
    <section id="fees" className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      
      {/* Section Header with light hairline rule */}
      <div className="text-left mb-10 pb-6 border-b border-slate-200 dark:border-sky-200/15">
        <div className="flex items-center gap-3 mb-2">
          <span className="h-px w-8 bg-[#0B1F3A] dark:bg-sky-300" aria-hidden="true" />
          <span className="text-xs font-semibold tracking-wider uppercase text-[#1A4073] dark:text-sky-300">
            Tuition &amp; Practical Training Investment
          </span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-cinzel font-bold text-[#0B1F3A] dark:text-white text-balance">
          {t.feesT}
        </h2>
        <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 mt-2 max-w-3xl leading-relaxed">
          {lang === 'en'
            ? 'Transparent fee schedule with official Mobile Money (MTN MoMo) code and accredited bank accounts for Saint Michael Technical High School.'
            : 'Uburyo bunoze bwo kwishyura amafaranga y\'ishuri no kwiyandikisha mukoresheje MoMo cyangwa amabanki yigenga.'}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column: Fees Schedule Table & Bank Cards */}
        <div className="lg:col-span-6 space-y-6">
          
          {/* Table with light small 1px lines */}
          <div className="overflow-hidden rounded-xl border border-slate-200 dark:border-sky-200/15 shadow-sm bg-white dark:bg-[#0B1D38]">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead className="bg-[#0B1F3A] text-white border-b border-sky-200/20">
                <tr>
                  <th className="py-3 px-4 font-semibold tracking-wide">{t.item}</th>
                  <th className="py-3 px-4 font-semibold tracking-wide text-right">{t.amount}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200/80 dark:divide-sky-200/10">
                {FEE_SCHEDULE.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50 dark:hover:bg-[#112D53]/50 transition-colors">
                    <td className="py-3.5 px-4 text-[#0B1F3A] dark:text-slate-100">
                      <div className="font-semibold">{t[item.labelKey as keyof typeof t]}</div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">{item.description}</div>
                    </td>
                    <td className="py-3.5 px-4 font-mono tabular-nums font-bold text-right text-sm sm:text-base text-[#0B1F3A] dark:text-sky-200 whitespace-nowrap">
                      {item.amountRwf.toLocaleString()} RWF
                    </td>
                  </tr>
                ))}
                <tr className="bg-[#F1F5F9] dark:bg-[#112D53]/70 font-semibold">
                  <td className="py-3.5 px-4 text-[#0B1F3A] dark:text-white">
                    Estimated Full First Term Package
                  </td>
                  <td className="py-3.5 px-4 font-mono tabular-nums font-bold text-right text-base text-[#0B1F3A] dark:text-sky-200 whitespace-nowrap">
                    200,000 RWF
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Payment Method Details Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-left">
            
            {/* MoMo Card */}
            <div className="p-4 rounded-xl border border-slate-200 dark:border-sky-200/15 bg-white dark:bg-[#0B1D38] shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100 dark:border-sky-200/10">
                  <span className="font-semibold text-sm text-[#0B1F3A] dark:text-white">MTN Mobile Money</span>
                  <span className="text-[11px] font-medium text-[#1A4073] dark:text-sky-300">Fast MoMo</span>
                </div>
                <div className="text-xs text-slate-600 dark:text-slate-300 font-mono mt-1">
                  Dial: <b className="text-sm text-[#0B1F3A] dark:text-sky-200">{PAYMENT_METHODS.momo.code}</b>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                  Acc: Saint Michael Technical High School
                </p>
              </div>
              <button
                type="button"
                onClick={() => handleCopyCode(PAYMENT_METHODS.momo.code, 'momo')}
                className="mt-3 w-full py-2 text-xs font-semibold rounded-lg bg-[#0B1F3A] text-white hover:bg-[#163868] dark:bg-sky-200 dark:text-[#0B1F3A] dark:hover:bg-white transition-colors flex items-center justify-center gap-1.5"
              >
                {copiedCode === 'momo' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedCode === 'momo' ? 'Copied' : 'Copy MoMo Code'}
              </button>
            </div>

            {/* Bank of Kigali Card */}
            <div className="p-4 rounded-xl border border-slate-200 dark:border-sky-200/15 bg-white dark:bg-[#0B1D38] shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100 dark:border-sky-200/10">
                  <span className="font-semibold text-sm text-[#0B1F3A] dark:text-white">Bank of Kigali (BK)</span>
                  <Building2 className="w-4 h-4 text-[#1A4073] dark:text-sky-300" />
                </div>
                <div className="text-xs text-slate-600 dark:text-slate-300 font-mono mt-1">
                  Acc: <b className="text-xs text-[#0B1F3A] dark:text-sky-200">{PAYMENT_METHODS.bk.accountNumber}</b>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                  Bank branch, BK App or BK Yacu
                </p>
              </div>
              <button
                type="button"
                onClick={() => handleCopyCode(PAYMENT_METHODS.bk.accountNumber, 'bk')}
                className="mt-3 w-full py-2 text-xs font-semibold rounded-lg bg-[#0B1F3A] text-white hover:bg-[#163868] dark:bg-sky-200 dark:text-[#0B1F3A] dark:hover:bg-white transition-colors flex items-center justify-center gap-1.5"
              >
                {copiedCode === 'bk' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedCode === 'bk' ? 'Copied' : 'Copy BK Account'}
              </button>
            </div>

          </div>

        </div>

        {/* Right Column: Interactive Payment Form & Digital Receipt */}
        <div className="lg:col-span-6">
          <div className="rounded-xl border border-slate-200 dark:border-sky-200/15 bg-white dark:bg-[#0B1D38] p-6 shadow-sm text-left">
            
            <div className="flex items-center justify-between pb-3.5 mb-5 border-b border-slate-200 dark:border-sky-200/15">
              <h3 className="text-lg sm:text-xl font-cinzel font-bold text-[#0B1F3A] dark:text-white flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-[#1A4073] dark:text-sky-300" />
                {t.formT}
              </h3>
              <span className="text-[11px] font-mono text-[#1A4073] dark:text-sky-300">
                Instant Receipt
              </span>
            </div>

            <form onSubmit={handlePaymentSubmit} className="space-y-4 text-xs sm:text-sm">
              
              {/* Student Full Name */}
              <div>
                <label className="block font-semibold text-[#0B1F3A] dark:text-slate-200 mb-1.5">
                  {t.fname} <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Mugisha Emmanuel"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-sky-200/20 bg-[#F8FAFC] dark:bg-[#061121] text-[#0B1F3A] dark:text-white focus:outline-none focus:border-[#0B1F3A] dark:focus:border-sky-300"
                />
              </div>

              {/* Phone and Registration Code */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#0B1F3A] dark:text-slate-200 mb-1.5">
                    {t.fphone} <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="0788XXXXXX"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-sky-200/20 bg-[#F8FAFC] dark:bg-[#061121] text-[#0B1F3A] dark:text-white focus:outline-none focus:border-[#0B1F3A] dark:focus:border-sky-300"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-[#0B1F3A] dark:text-slate-200 mb-1.5">
                    {t.regCodeLabel} <span className="text-slate-400 font-normal">(if registered)</span>
                  </label>
                  <input
                    type="text"
                    placeholder="SMTHS-2025-XXXX"
                    value={regCode}
                    onChange={(e) => setRegCode(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-sky-200/20 bg-[#F8FAFC] dark:bg-[#061121] text-[#0B1F3A] dark:text-white uppercase font-mono text-xs focus:outline-none focus:border-[#0B1F3A] dark:focus:border-sky-300"
                  />
                </div>
              </div>

              {/* Program & Fee Category */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#0B1F3A] dark:text-slate-200 mb-1.5">
                    {t.fprog}
                  </label>
                  <select
                    value={prog}
                    onChange={(e) => setProg(e.target.value as ProgramId)}
                    className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-sky-200/20 bg-[#F8FAFC] dark:bg-[#061121] text-[#0B1F3A] dark:text-white focus:outline-none focus:border-[#0B1F3A] dark:focus:border-sky-300"
                  >
                    {PROGRAMS.map((p) => (
                      <option key={p.id} value={p.id}>
                        {t[p.id]}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-[#0B1F3A] dark:text-slate-200 mb-1.5">
                    {t.fitem}
                  </label>
                  <select
                    value={itemType}
                    onChange={(e) => setItemType(e.target.value as any)}
                    className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-sky-200/20 bg-[#F8FAFC] dark:bg-[#061121] text-[#0B1F3A] dark:text-white focus:outline-none focus:border-[#0B1F3A] dark:focus:border-sky-300"
                  >
                    <option value="registration">{t.reg} (20,000 RWF)</option>
                    <option value="term_tuition">{t.term} (120,000 RWF)</option>
                    <option value="uniform">{t.uni} (35,000 RWF)</option>
                    <option value="materials">{t.mat} (25,000 RWF)</option>
                    <option value="full_package">Full First Term Package (200,000 RWF)</option>
                  </select>
                </div>
              </div>

              {/* Payment Method Selector */}
              <div>
                <label className="block font-semibold text-[#0B1F3A] dark:text-slate-200 mb-1.5">
                  {t.fmethod}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {(['momo', 'bk', 'bpr', 'equity'] as const).map((m) => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setMethod(m)}
                      className={`py-2 px-2.5 text-xs font-semibold rounded-lg border transition-colors ${
                        method === m
                          ? 'bg-[#0B1F3A] text-white border-[#0B1F3A] dark:bg-sky-200 dark:text-[#0B1F3A] dark:border-sky-200'
                          : 'bg-[#F8FAFC] dark:bg-[#061121] text-[#0B1F3A] dark:text-slate-200 border-slate-300 dark:border-sky-200/20 hover:border-[#0B1F3A]/50'
                      }`}
                    >
                      {m === 'momo' ? 'MoMo' : m.toUpperCase()}
                    </button>
                  ))}
                </div>
              </div>

              {/* Live Payment Instruction Box */}
              <div className="p-4 rounded-xl border border-slate-200 dark:border-sky-200/20 bg-[#F1F5F9] dark:bg-[#112D53]/45 space-y-1.5">
                <div className="font-semibold text-xs uppercase tracking-wider text-[#1A4073] dark:text-sky-300 pb-1 border-b border-slate-200 dark:border-sky-200/15">
                  {t.payD} · {selectedMethodInfo.name}
                </div>
                <div className="text-xs font-medium text-slate-700 dark:text-slate-200 pt-1">
                  {method === 'momo' ? (
                    <span>{t.code}: <b className="font-mono text-sm text-[#0B1F3A] dark:text-white">{PAYMENT_METHODS.momo.code}</b></span>
                  ) : (
                    <span>{t.accno}: <b className="font-mono text-xs text-[#0B1F3A] dark:text-white">{(selectedMethodInfo as { accountNumber: string }).accountNumber}</b></span>
                  )}
                </div>
                <div className="text-[11px] text-slate-600 dark:text-slate-300">
                  {t.accname}: <b>{selectedMethodInfo.accountName}</b>
                </div>
                <div className="text-xs font-semibold pt-2 border-t border-slate-200 dark:border-sky-200/15 text-[#0B1F3A] dark:text-white flex items-center justify-between">
                  <span>Total to Pay</span>
                  <span className="font-mono tabular-nums text-base">{getAmountForCategory().toLocaleString()} RWF</span>
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="w-full py-3 px-4 rounded-lg font-semibold bg-[#0B1F3A] text-white hover:bg-[#163868] dark:bg-sky-200 dark:text-[#0B1F3A] dark:hover:bg-white transition-colors shadow-sm text-sm flex items-center justify-center gap-2"
              >
                <CheckCircle className="w-4 h-4" />
                {t.submit} ({getAmountForCategory().toLocaleString()} RWF)
              </button>

            </form>

            {/* Payment Confirmation Card */}
            {paymentResult && (
              <div className="mt-5 p-4 rounded-xl border border-emerald-600/35 bg-emerald-50/80 dark:bg-emerald-950/30 text-emerald-900 dark:text-emerald-200 space-y-2.5">
                <div className="flex items-center gap-2 font-semibold text-sm text-emerald-800 dark:text-emerald-300">
                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                  <span>{t.thanks}, {paymentResult.studentName}!</span>
                </div>
                <p className="text-xs">
                  {t.instr}
                </p>
                <div className="bg-white dark:bg-[#061121] p-3 rounded-lg border border-emerald-200 dark:border-emerald-700/40 font-mono text-xs space-y-1 tabular-nums">
                  <div><strong>Txn Reference:</strong> {paymentResult.refNumber}</div>
                  <div><strong>Amount Paid:</strong> {paymentResult.amount.toLocaleString()} RWF</div>
                  <div><strong>Method:</strong> {paymentResult.method.toUpperCase()}</div>
                  <div><strong>Category:</strong> {paymentResult.itemType}</div>
                  <div><strong>Verified Date:</strong> {new Date(paymentResult.createdAt).toLocaleDateString()}</div>
                </div>
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="w-full py-2 bg-[#0B1F3A] text-white rounded-lg font-semibold text-xs hover:bg-[#163868] transition-colors flex items-center justify-center gap-1.5"
                >
                  <Printer className="w-3.5 h-3.5" />
                  {t.rPrint}
                </button>
              </div>
            )}

          </div>
        </div>

      </div>

    </section>
  );
};
