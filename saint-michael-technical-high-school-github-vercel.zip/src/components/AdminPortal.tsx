import React, { useState } from 'react';
import { Language } from '../types/index.ts';
import { storageService } from '../services/storageService.ts';
import { T } from '../data/translations.ts';
import { 
  X, 
  Search, 
  Users, 
  CreditCard, 
  Award, 
  FileSpreadsheet,
  FileJson,
  Building
} from 'lucide-react';

interface AdminPortalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  onRefresh: () => void;
}

export const AdminPortal: React.FC<AdminPortalProps> = ({
  isOpen,
  onClose,
  lang,
  onRefresh
}) => {
  const t = T[lang];
  const [activeTab, setActiveTab] = useState<'students' | 'payments'>('students');
  const [searchQuery, setSearchQuery] = useState('');
  const [progFilter, setProgFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  if (!isOpen) return null;

  const registrations = storageService.getRegistrations();
  const payments = storageService.getPayments();

  // Metrics
  const totalStudents = registrations.length;
  const totalFeesCollected = payments.reduce((acc, p) => acc + p.amount, 0);
  const admittedCount = registrations.filter(r => r.status === 'admitted').length;

  // Filtered Students
  const filteredRegistrations = registrations.filter(r => {
    const matchesSearch = 
      r.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.regCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.phone.includes(searchQuery);
    const matchesProg = progFilter === 'all' || r.prog === progFilter;
    const matchesStatus = statusFilter === 'all' || r.status === statusFilter;
    return matchesSearch && matchesProg && matchesStatus;
  });

  // Filtered Payments
  const filteredPayments = payments.filter(p => {
    return p.studentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
           p.refNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
           (p.regCode && p.regCode.toLowerCase().includes(searchQuery.toLowerCase()));
  });

  const handleStatusChange = (id: string, newStatus: 'pending' | 'verified' | 'admitted') => {
    storageService.updateRegistrationStatus(id, newStatus);
    onRefresh();
  };

  const downloadCsv = (type: 'registrations' | 'payments') => {
    const csvData = storageService.exportAsCsv(type);
    const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `SMTHS_${type}_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const downloadJson = () => {
    const jsonData = storageService.exportAsJson();
    const blob = new Blob([jsonData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `SMTHS_database_backup_${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4">
      <div className="bg-[#F8FAFC] dark:bg-[#061121] text-[#0B1F3A] dark:text-slate-100 w-full max-w-6xl rounded-2xl border border-slate-300 dark:border-sky-200/20 shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="bg-[#0B1F3A] text-white p-4 sm:p-5 flex items-center justify-between border-b border-sky-200/20">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-white/10 border border-sky-200/25 text-sky-200 flex items-center justify-center">
              <Building className="w-5 h-5" />
            </div>
            <div className="text-left">
              <h2 className="text-base sm:text-lg font-cinzel font-bold text-white">
                Saint Michael THS — Administration Portal
              </h2>
              <p className="text-xs text-sky-200/80">
                Official records management, student admissions &amp; fee verification
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => downloadCsv('registrations')}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-white text-[#0B1F3A] rounded-lg text-xs font-semibold hover:bg-sky-100 transition-colors"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              CSV Export
            </button>
            <button
              onClick={downloadJson}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 border border-sky-200/25 bg-white/10 text-white rounded-lg text-xs font-semibold hover:bg-white/20 transition-colors"
            >
              <FileJson className="w-3.5 h-3.5" />
              JSON Backup
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg hover:bg-white/15 text-white transition-colors"
              aria-label="Close admin modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Overview Stats Strip */}
        <div className="bg-white dark:bg-[#0B1D38] grid grid-cols-1 sm:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x divide-slate-200 dark:divide-sky-200/15 border-b border-slate-200 dark:border-sky-200/15 text-left">
          <div className="p-4 sm:px-6 flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#F1F5F9] dark:bg-[#112D53] border border-slate-200 dark:border-sky-200/15 text-[#0B1F3A] dark:text-sky-200 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 block">
                Total Registrations
              </span>
              <span className="text-xl font-bold font-mono tabular-nums text-[#0B1F3A] dark:text-white">{totalStudents}</span>
            </div>
          </div>

          <div className="p-4 sm:px-6 flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#F1F5F9] dark:bg-[#112D53] border border-slate-200 dark:border-sky-200/15 text-[#0B1F3A] dark:text-sky-200 flex items-center justify-center">
              <CreditCard className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 block">
                Total Fees Verified
              </span>
              <span className="text-xl font-bold font-mono tabular-nums text-[#0B1F3A] dark:text-white">{totalFeesCollected.toLocaleString()} RWF</span>
            </div>
          </div>

          <div className="p-4 sm:px-6 flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#F1F5F9] dark:bg-[#112D53] border border-slate-200 dark:border-sky-200/15 text-[#0B1F3A] dark:text-sky-200 flex items-center justify-center">
              <Award className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 block">
                Admitted Candidates
              </span>
              <span className="text-xl font-bold font-mono tabular-nums text-[#0B1F3A] dark:text-white">{admittedCount}</span>
            </div>
          </div>
        </div>

        {/* Tab & Filter Bar */}
        <div className="px-4 sm:px-6 py-3 bg-[#F1F5F9] dark:bg-[#08172B] border-b border-slate-200 dark:border-sky-200/15 flex flex-wrap items-center justify-between gap-3 text-xs">
          
          {/* Tabs */}
          <div className="flex items-center gap-1 p-1 bg-white dark:bg-[#061121] rounded-lg border border-slate-200 dark:border-sky-200/15 font-semibold">
            <button
              onClick={() => setActiveTab('students')}
              className={`px-3 py-1.5 rounded-md transition-colors ${
                activeTab === 'students'
                  ? 'bg-[#0B1F3A] text-white dark:bg-sky-200 dark:text-[#0B1F3A]'
                  : 'text-slate-600 dark:text-slate-300 hover:text-[#0B1F3A] dark:hover:text-white'
              }`}
            >
              Registered Students ({registrations.length})
            </button>
            <button
              onClick={() => setActiveTab('payments')}
              className={`px-3 py-1.5 rounded-md transition-colors ${
                activeTab === 'payments'
                  ? 'bg-[#0B1F3A] text-white dark:bg-sky-200 dark:text-[#0B1F3A]'
                  : 'text-slate-600 dark:text-slate-300 hover:text-[#0B1F3A] dark:hover:text-white'
              }`}
            >
              Fee Payments ({payments.length})
            </button>
          </div>

          {/* Search & Filters */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search name, code, phone..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 pr-3 py-1.5 rounded-lg border border-slate-300 dark:border-sky-200/20 bg-white dark:bg-[#061121] text-xs text-current w-48 sm:w-56 focus:outline-none focus:border-[#0B1F3A] dark:focus:border-sky-300"
              />
            </div>

            {activeTab === 'students' && (
              <>
                <select
                  value={progFilter}
                  onChange={(e) => setProgFilter(e.target.value)}
                  className="px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-sky-200/20 bg-white dark:bg-[#061121] text-xs text-current"
                >
                  <option value="all">All Programs</option>
                  <option value="p1">Software Dev</option>
                  <option value="p2">Food &amp; Beverage</option>
                  <option value="p3">Computer Systems</option>
                  <option value="p4">Architecture</option>
                  <option value="p5">Multimedia</option>
                </select>

                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-sky-200/20 bg-white dark:bg-[#061121] text-xs text-current"
                >
                  <option value="all">All Statuses</option>
                  <option value="pending">Pending</option>
                  <option value="verified">Verified</option>
                  <option value="admitted">Admitted</option>
                </select>
              </>
            )}
          </div>

        </div>

        {/* Content Table */}
        <div className="flex-1 overflow-auto p-4 sm:p-6 text-left">
          
          {activeTab === 'students' ? (
            <div className="bg-white dark:bg-[#0B1D38] rounded-xl border border-slate-200 dark:border-sky-200/15 overflow-hidden shadow-sm">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#0B1F3A] text-white border-b border-sky-200/20">
                  <tr>
                    <th className="py-2.5 px-3 font-semibold uppercase tracking-wider">Reg Code</th>
                    <th className="py-2.5 px-3 font-semibold uppercase tracking-wider">Student Name</th>
                    <th className="py-2.5 px-3 font-semibold uppercase tracking-wider">Trade</th>
                    <th className="py-2.5 px-3 font-semibold uppercase tracking-wider">District</th>
                    <th className="py-2.5 px-3 font-semibold uppercase tracking-wider">Parent Phone</th>
                    <th className="py-2.5 px-3 font-semibold uppercase tracking-wider">Status</th>
                    <th className="py-2.5 px-3 font-semibold uppercase tracking-wider">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200/80 dark:divide-sky-200/10">
                  {filteredRegistrations.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-slate-500">
                        No registrations match the filter.
                      </td>
                    </tr>
                  ) : (
                    filteredRegistrations.map((student) => (
                      <tr key={student.id} className="hover:bg-slate-50 dark:hover:bg-[#112D53]/40 transition-colors">
                        <td className="py-3 px-3 font-mono tabular-nums font-bold text-[#0B1F3A] dark:text-sky-200">
                          {student.regCode}
                        </td>
                        <td className="py-3 px-3 font-semibold text-slate-900 dark:text-slate-100">
                          {student.name}
                          {student.school && (
                            <span className="block text-[10px] text-slate-500 dark:text-slate-400 font-normal">
                              Prev: {student.school}
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-3 font-mono font-semibold text-slate-700 dark:text-slate-300">
                          {student.prog.toUpperCase()}
                        </td>
                        <td className="py-3 px-3 text-slate-600 dark:text-slate-300">
                          {student.district}
                        </td>
                        <td className="py-3 px-3 font-mono tabular-nums">
                          {student.phone}
                        </td>
                        <td className="py-3 px-3">
                          <span className={`text-[11px] font-semibold uppercase tracking-wider ${
                            student.status === 'admitted'
                              ? 'text-sky-700 dark:text-sky-300'
                              : student.status === 'verified'
                              ? 'text-emerald-700 dark:text-emerald-400'
                              : 'text-amber-700 dark:text-amber-300'
                          }`}>
                            {student.status}
                          </span>
                        </td>
                        <td className="py-3 px-3">
                          <select
                            value={student.status}
                            onChange={(e) => handleStatusChange(student.id, e.target.value as any)}
                            className="text-[11px] px-2 py-1 rounded border border-slate-300 dark:border-sky-200/20 bg-white dark:bg-[#061121] text-current font-medium"
                          >
                            <option value="pending">Pending</option>
                            <option value="verified">Verified</option>
                            <option value="admitted">Admitted</option>
                          </select>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="bg-white dark:bg-[#0B1D38] rounded-xl border border-slate-200 dark:border-sky-200/15 overflow-hidden shadow-sm">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#0B1F3A] text-white border-b border-sky-200/20">
                  <tr>
                    <th className="py-2.5 px-3 font-semibold uppercase tracking-wider">Txn Ref</th>
                    <th className="py-2.5 px-3 font-semibold uppercase tracking-wider">Student Name</th>
                    <th className="py-2.5 px-3 font-semibold uppercase tracking-wider">Method</th>
                    <th className="py-2.5 px-3 font-semibold uppercase tracking-wider">Amount (RWF)</th>
                    <th className="py-2.5 px-3 font-semibold uppercase tracking-wider">Item</th>
                    <th className="py-2.5 px-3 font-semibold uppercase tracking-wider">Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200/80 dark:divide-sky-200/10">
                  {filteredPayments.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-500">
                        No fee payments match the query.
                      </td>
                    </tr>
                  ) : (
                    filteredPayments.map((pay) => (
                      <tr key={pay.id} className="hover:bg-slate-50 dark:hover:bg-[#112D53]/40 transition-colors">
                        <td className="py-3 px-3 font-mono tabular-nums font-bold text-[#1A4073] dark:text-sky-300">
                          {pay.refNumber}
                        </td>
                        <td className="py-3 px-3 font-semibold text-slate-900 dark:text-slate-100">
                          {pay.studentName}
                          {pay.regCode && (
                            <span className="block text-[10px] text-slate-500 dark:text-slate-400 font-mono">
                              Code: {pay.regCode}
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-3 font-semibold uppercase">
                          {pay.method}
                        </td>
                        <td className="py-3 px-3 font-mono tabular-nums font-bold text-sm text-[#0B1F3A] dark:text-sky-200">
                          {pay.amount.toLocaleString()} RWF
                        </td>
                        <td className="py-3 px-3 text-slate-600 dark:text-slate-300">
                          {pay.itemType}
                        </td>
                        <td className="py-3 px-3 text-slate-500 dark:text-slate-400 font-mono tabular-nums text-[11px]">
                          {new Date(pay.createdAt).toLocaleDateString()}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="bg-[#0B1F3A] text-sky-100 p-3 px-6 flex items-center justify-between text-xs border-t border-sky-200/20">
          <span>{t.liveBackend}</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-white text-[#0B1F3A] font-semibold hover:bg-sky-100 transition-colors"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
