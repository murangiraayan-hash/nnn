import React, { useState } from 'react';
import { generateFullProjectZip, generatePhpOnlyZip } from '../services/zipExportService.ts';
import { 
  X, 
  Download, 
  FolderArchive, 
  Database, 
  Globe, 
  CheckCircle2, 
  Server,
  Copy,
  ExternalLink,
  Github,
  Rocket
} from 'lucide-react';

interface DownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DownloadModal: React.FC<DownloadModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'download' | 'guide'>('download');
  const [downloading, setDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);
  const [copiedSnippet, setCopiedSnippet] = useState<string | null>(null);

  if (!isOpen) return null;

  const triggerDownloadFromUrl = (url: string, filename: string) => {
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const triggerDownloadBlob = (blob: Blob, filename: string) => {
    const url = URL.createObjectURL(blob);
    triggerDownloadFromUrl(url, filename);
    URL.revokeObjectURL(url);
  };

  const handleDownloadGithubVercelZip = async () => {
    setDownloading(true);
    try {
      const res = await fetch('/downloads/saint-michael-technical-high-school.zip');
      if (res.ok) {
        const blob = await res.blob();
        triggerDownloadBlob(blob, 'saint-michael-technical-high-school-github-vercel.zip');
        setDownloadSuccess('GitHub & Vercel Ready Project (.ZIP) downloaded!');
      } else {
        const zipBlob = await generateFullProjectZip();
        triggerDownloadBlob(zipBlob, 'saint-michael-technical-high-school-full-project.zip');
        setDownloadSuccess('Complete Project ZIP generated and downloaded!');
      }
      setTimeout(() => setDownloadSuccess(null), 4000);
    } catch (err) {
      console.error(err);
      const zipBlob = await generateFullProjectZip();
      triggerDownloadBlob(zipBlob, 'saint-michael-technical-high-school-full-project.zip');
      setDownloadSuccess('Project ZIP downloaded!');
      setTimeout(() => setDownloadSuccess(null), 4000);
    } finally {
      setDownloading(false);
    }
  };

  const handleDownloadPhpZip = async () => {
    setDownloading(true);
    try {
      const zipBlob = await generatePhpOnlyZip();
      triggerDownloadBlob(zipBlob, 'smths_php_backend_files.zip');
      setDownloadSuccess('PHP 8 & MySQL Backend ZIP downloaded successfully!');
      setTimeout(() => setDownloadSuccess(null), 4000);
    } catch (err) {
      console.error(err);
    } finally {
      setDownloading(false);
    }
  };

  const handleDownloadCompiledZip = async () => {
    setDownloading(true);
    try {
      const res = await fetch('/downloads/saint-michael-compiled-website.zip');
      if (res.ok) {
        const blob = await res.blob();
        triggerDownloadBlob(blob, 'saint-michael-compiled-website.zip');
        setDownloadSuccess('Compiled Production Website (.ZIP) downloaded!');
      } else {
        triggerDownloadFromUrl('/downloads/saint-michael-compiled-website.zip', 'saint-michael-compiled-website.zip');
        setDownloadSuccess('Compiled Website ZIP downloaded!');
      }
      setTimeout(() => setDownloadSuccess(null), 4000);
    } catch (err) {
      console.error(err);
      triggerDownloadFromUrl('/downloads/saint-michael-compiled-website.zip', 'saint-michael-compiled-website.zip');
    } finally {
      setDownloading(false);
    }
  };

  const handleDownloadSql = () => {
    fetch('/backend/database.sql')
      .then(res => res.blob())
      .then(blob => {
        triggerDownloadBlob(blob, 'database.sql');
        setDownloadSuccess('database.sql downloaded!');
        setTimeout(() => setDownloadSuccess(null), 3000);
      });
  };

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSnippet(label);
    setTimeout(() => setCopiedSnippet(null), 3000);
  };

  const gitCommands = `git init
git add .
git commit -m "Saint Michael Technical High School Portal"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/saint-michael-high-school.git
git push -u origin main`;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-fadeIn">
      <div className="bg-[#F8FAFC] dark:bg-[#061121] text-[#0B1F3A] dark:text-slate-100 w-full max-w-3xl rounded-2xl border border-slate-300 dark:border-sky-200/20 shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="bg-[#0B1F3A] text-white p-5 sm:p-6 flex items-center justify-between border-b border-sky-200/20 flex-none">
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-lg bg-white/10 border border-sky-200/25 text-sky-200 flex items-center justify-center">
              <Rocket className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-cinzel font-bold text-white">
                GitHub &amp; Vercel Hosting Center
              </h2>
              <p className="text-xs text-slate-300">
                Download project files, push to GitHub, and deploy to Vercel for your public link
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg border border-transparent hover:border-sky-200/25 hover:bg-white/10 text-white transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex bg-[#F1F5F9] dark:bg-[#08172B] border-b border-slate-200 dark:border-sky-200/15 p-1.5 gap-1.5 px-6 flex-none">
          <button
            onClick={() => setActiveTab('download')}
            className={`flex-1 py-2 px-4 rounded-lg text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer border ${
              activeTab === 'download'
                ? 'bg-[#0B1F3A] dark:bg-[#163868] text-white border-sky-200/25 shadow-sm'
                : 'text-[#0B1F3A] dark:text-slate-200 border-transparent hover:bg-white/70 dark:hover:bg-white/5'
            }`}
          >
            <Download className="w-4 h-4" />
            <span>Download Files (.ZIP)</span>
          </button>
          <button
            onClick={() => setActiveTab('guide')}
            className={`flex-1 py-2 px-4 rounded-lg text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer border ${
              activeTab === 'guide'
                ? 'bg-[#0B1F3A] dark:bg-[#163868] text-white border-sky-200/25 shadow-sm'
                : 'text-[#0B1F3A] dark:text-slate-200 border-transparent hover:bg-white/70 dark:hover:bg-white/5'
            }`}
          >
            <Rocket className="w-4 h-4" />
            <span>How to Host on Vercel &amp; GitHub</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-7 space-y-6 text-left overflow-y-auto flex-1">
          
          {downloadSuccess && (
            <div className="p-3 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-800 dark:text-emerald-200 rounded-lg text-xs font-semibold flex items-center gap-2 animate-fadeIn border border-emerald-300 dark:border-emerald-700/50">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 flex-none" />
              <span>{downloadSuccess}</span>
            </div>
          )}

          {activeTab === 'download' ? (
            <>
              {/* Primary Option: GitHub & Vercel Ready ZIP */}
              <div className="p-6 rounded-xl bg-white dark:bg-[#0B1D38] border border-slate-300 dark:border-sky-200/20 shadow-sm relative">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 mb-4 border-b border-slate-200 dark:border-sky-200/15">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-[#0B1F3A] dark:bg-[#112D53] border border-sky-200/20 text-sky-100 flex items-center justify-center flex-none">
                      <FolderArchive className="w-5 h-5" />
                    </div>
                    <h3 className="font-cinzel text-base sm:text-lg font-bold text-[#0B1F3A] dark:text-white">
                      Complete React + Vite + Tailwind Project (.ZIP)
                    </h3>
                  </div>
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-emerald-700 dark:text-emerald-300 flex items-center gap-1.5 flex-none">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Ready for GitHub &amp; Vercel
                  </span>
                </div>

                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  This is the <strong className="text-[#0B1F3A] dark:text-white">exact full web application</strong> running in this portal. It contains all files needed to upload directly to GitHub and deploy to Vercel with zero extra setup.
                </p>

                <div className="mt-4 rounded-lg bg-[#F8FAFC] dark:bg-[#061121] border border-slate-200 dark:border-sky-200/15 text-[11px] text-slate-700 dark:text-slate-300 divide-y divide-slate-200/80 dark:divide-sky-200/10 font-mono">
                  <div className="px-3.5 py-2 font-sans font-semibold text-[#0B1F3A] dark:text-sky-200 uppercase tracking-wider text-[10px]">
                    Key files included
                  </div>
                  <div className="px-3.5 py-2">
                    <strong className="text-[#0B1F3A] dark:text-white">vercel.json</strong> — preconfigured SPA rewrite for clean URLs on Vercel
                  </div>
                  <div className="px-3.5 py-2">
                    <strong className="text-[#0B1F3A] dark:text-white">package.json</strong> &amp; <strong className="text-[#0B1F3A] dark:text-white">vite.config.ts</strong> — Vite 8, React 19, Tailwind CSS v4
                  </div>
                  <div className="px-3.5 py-2">
                    <strong className="text-[#0B1F3A] dark:text-white">src/</strong> — All React components, admissions, fees calculator, themes
                  </div>
                  <div className="px-3.5 py-2">
                    <strong className="text-[#0B1F3A] dark:text-white">public/</strong> — Saint Michael crest logo, background videos, assets
                  </div>
                  <div className="px-3.5 py-2">
                    <strong className="text-[#0B1F3A] dark:text-white">README.md</strong> — Complete copy-paste GitHub and Vercel guide
                  </div>
                  <div className="px-3.5 py-2">
                    <strong className="text-[#0B1F3A] dark:text-white">public/backend/</strong> — Companion PHP 8 &amp; MySQL files for XAMPP
                  </div>
                </div>

                <div className="mt-5 flex flex-wrap gap-3 items-center">
                  <button
                    type="button"
                    onClick={handleDownloadGithubVercelZip}
                    disabled={downloading}
                    className="px-5 py-2.5 rounded-lg font-semibold bg-[#0B1F3A] dark:bg-sky-200 text-white dark:text-[#061121] hover:bg-[#163868] dark:hover:bg-white transition-colors shadow-sm text-xs sm:text-sm flex items-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    <Download className="w-4 h-4" />
                    {downloading ? 'Preparing ZIP...' : 'Download Full Project (.ZIP - 1.3 MB)'}
                  </button>

                  <button
                    type="button"
                    onClick={() => setActiveTab('guide')}
                    className="px-4 py-2.5 rounded-lg font-semibold bg-transparent text-[#0B1F3A] dark:text-sky-200 hover:bg-slate-100 dark:hover:bg-white/5 transition-colors text-xs flex items-center gap-1.5 border border-slate-300 dark:border-sky-200/25 cursor-pointer"
                  >
                    <Rocket className="w-3.5 h-3.5" />
                    View 2-Min Vercel Guide &rarr;
                  </button>
                </div>
              </div>

              {/* Secondary Individual Options */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                
                {/* Compiled Production Website */}
                <div className="p-4 rounded-xl bg-white dark:bg-[#0B1D38] border border-slate-200 dark:border-sky-200/15 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-1.5 text-xs font-bold text-[#0B1F3A] dark:text-white mb-1.5 pb-2 border-b border-slate-100 dark:border-sky-200/10">
                      <Globe className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                      <span>Pre-built Website (.ZIP)</span>
                    </div>
                    <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                      Already-compiled production website (<code className="text-[10px]">index.html</code>, <code className="text-[10px]">assets/</code>). Ready to drag &amp; drop into Netlify or any host.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleDownloadCompiledZip}
                    disabled={downloading}
                    className="mt-4 py-2 px-3 bg-[#F8FAFC] dark:bg-[#112D53] text-[#0B1F3A] dark:text-sky-100 rounded-lg font-semibold text-xs hover:bg-[#0B1F3A] hover:text-white dark:hover:bg-sky-200 dark:hover:text-[#061121] transition-colors flex items-center justify-center gap-1.5 border border-slate-200 dark:border-sky-200/20 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" /> Download Built Web
                  </button>
                </div>

                {/* PHP Backend Only ZIP */}
                <div className="p-4 rounded-xl bg-white dark:bg-[#0B1D38] border border-slate-200 dark:border-sky-200/15 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-1.5 text-xs font-bold text-[#0B1F3A] dark:text-white mb-1.5 pb-2 border-b border-slate-100 dark:border-sky-200/10">
                      <Server className="w-3.5 h-3.5 text-[#163868] dark:text-sky-300" />
                      <span>PHP 8 Backend ZIP</span>
                    </div>
                    <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                      Standalone PHP files (<code className="text-[10px]">register.php</code>, <code className="text-[10px]">pay.php</code>, <code className="text-[10px]">admin.php</code>) for evaluation in XAMPP or school lab.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleDownloadPhpZip}
                    disabled={downloading}
                    className="mt-4 py-2 px-3 bg-[#F8FAFC] dark:bg-[#112D53] text-[#0B1F3A] dark:text-sky-100 rounded-lg font-semibold text-xs hover:bg-[#0B1F3A] hover:text-white dark:hover:bg-sky-200 dark:hover:text-[#061121] transition-colors flex items-center justify-center gap-1.5 border border-slate-200 dark:border-sky-200/20 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" /> Download PHP ZIP
                  </button>
                </div>

                {/* database.sql Only */}
                <div className="p-4 rounded-xl bg-white dark:bg-[#0B1D38] border border-slate-200 dark:border-sky-200/15 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-1.5 text-xs font-bold text-[#0B1F3A] dark:text-white mb-1.5 pb-2 border-b border-slate-100 dark:border-sky-200/10">
                      <Database className="w-3.5 h-3.5 text-[#163868] dark:text-sky-300" />
                      <span>MySQL Database (.sql)</span>
                    </div>
                    <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                      <code className="text-[10px]">database.sql</code> script ready to import in phpMyAdmin to create <code className="text-[10px]">smths_school_db</code> and tables.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleDownloadSql}
                    className="mt-4 py-2 px-3 bg-[#F8FAFC] dark:bg-[#112D53] text-[#0B1F3A] dark:text-sky-100 rounded-lg font-semibold text-xs hover:bg-[#0B1F3A] hover:text-white dark:hover:bg-sky-200 dark:hover:text-[#061121] transition-colors flex items-center justify-center gap-1.5 border border-slate-200 dark:border-sky-200/20 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" /> Download .sql
                  </button>
                </div>

              </div>
            </>
          ) : (
            /* Guide Tab: How to Deploy to GitHub & Vercel */
            <div className="space-y-5">
              
              {/* Intro banner */}
              <div className="p-4 rounded-xl bg-white dark:bg-[#0B1D38] border border-slate-200 dark:border-sky-200/20 text-[#0B1F3A] dark:text-slate-200 text-xs flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 flex-none" />
                <span>
                  <strong className="text-[#0B1F3A] dark:text-white">Ready out of the box.</strong> The project already has <code className="font-mono text-[#163868] dark:text-sky-300">vercel.json</code> configured for single-page routing, so direct links and refreshes work cleanly.
                </span>
              </div>

              <div className="rounded-xl bg-white dark:bg-[#0B1D38] border border-slate-200 dark:border-sky-200/15 divide-y divide-slate-200 dark:divide-sky-200/15">
                {/* Step 1: Download files */}
                <div className="p-5 flex gap-4 items-start">
                  <div className="w-7 h-7 rounded-md bg-[#0B1F3A] dark:bg-[#112D53] border border-sky-200/25 text-white font-bold text-xs tabular-nums flex items-center justify-center flex-none">
                    1
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold text-sm text-[#0B1F3A] dark:text-white">
                      Download &amp; Unzip the Project
                    </h4>
                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">
                      Click the button below to download the complete codebase as a zip archive and extract it on your computer.
                    </p>
                    <button
                      onClick={handleDownloadGithubVercelZip}
                      disabled={downloading}
                      className="mt-3 px-3.5 py-1.5 bg-[#F8FAFC] dark:bg-[#112D53] text-[#0B1F3A] dark:text-sky-100 rounded-lg text-xs font-semibold hover:bg-[#0B1F3A] hover:text-white dark:hover:bg-sky-200 dark:hover:text-[#061121] transition-colors border border-slate-200 dark:border-sky-200/20 inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      Download ZIP (1.3 MB)
                    </button>
                  </div>
                </div>

                {/* Step 2: Upload to GitHub */}
                <div className="p-5 flex gap-4 items-start">
                  <div className="w-7 h-7 rounded-md bg-[#0B1F3A] dark:bg-[#112D53] border border-sky-200/25 text-white font-bold text-xs tabular-nums flex items-center justify-center flex-none">
                    2
                  </div>
                  <div className="flex-1">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <h4 className="font-bold text-sm text-[#0B1F3A] dark:text-white flex items-center gap-1.5">
                        <Github className="w-4 h-4" /> Push to GitHub
                      </h4>
                      <a
                        href="https://github.com/new"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs font-semibold text-[#163868] dark:text-sky-300 hover:underline inline-flex items-center gap-1"
                      >
                        Open github.com/new <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">
                      Create a new repository on GitHub (e.g. <code className="font-mono">saint-michael-high-school</code>) and push the extracted files:
                    </p>

                    {/* Terminal snippet */}
                    <div className="mt-3 bg-[#061121] text-slate-200 p-3.5 rounded-lg border border-sky-200/15 font-mono text-[11px] relative overflow-x-auto">
                      <button
                        onClick={() => handleCopy(gitCommands, 'git')}
                        className="absolute top-2.5 right-2.5 px-2.5 py-1 bg-white/10 hover:bg-white/20 border border-sky-200/20 text-white rounded text-[10px] flex items-center gap-1 cursor-pointer"
                      >
                        {copiedSnippet === 'git' ? (
                          <>
                            <CheckCircle2 className="w-3 h-3 text-emerald-400" /> Copied
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" /> Copy
                          </>
                        )}
                      </button>
                      <pre className="pr-16 leading-relaxed">{gitCommands}</pre>
                    </div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1.5">
                      Or use GitHub&apos;s web interface to drag &amp; drop the extracted project files into your repository.
                    </p>
                  </div>
                </div>

                {/* Step 3: Deploy to Vercel */}
                <div className="p-5 flex gap-4 items-start">
                  <div className="w-7 h-7 rounded-md bg-[#0B1F3A] dark:bg-[#112D53] border border-sky-200/25 text-white font-bold text-xs tabular-nums flex items-center justify-center flex-none">
                    3
                  </div>
                  <div className="flex-1">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <h4 className="font-bold text-sm text-[#0B1F3A] dark:text-white flex items-center gap-1.5">
                        <Rocket className="w-4 h-4 text-emerald-600 dark:text-emerald-400" /> Deploy on Vercel (1-Click)
                      </h4>
                      <a
                        href="https://vercel.com/new"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs font-semibold text-[#163868] dark:text-sky-300 hover:underline inline-flex items-center gap-1"
                      >
                        Open vercel.com/new <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">
                      Log in with GitHub, select your repository, and click <strong className="text-[#0B1F3A] dark:text-white">Deploy</strong>:
                    </p>

                    <div className="mt-3 grid grid-cols-2 sm:grid-cols-4 border border-slate-200 dark:border-sky-200/15 rounded-lg overflow-hidden divide-y sm:divide-y-0 sm:divide-x divide-slate-200 dark:divide-sky-200/15 bg-[#F8FAFC] dark:bg-[#061121] text-center text-xs">
                      <div className="p-2.5">
                        <span className="text-[10px] uppercase tracking-wider text-slate-500 dark:text-slate-400 block">Preset</span>
                        <strong className="text-[#0B1F3A] dark:text-white">Vite</strong>
                      </div>
                      <div className="p-2.5">
                        <span className="text-[10px] uppercase tracking-wider text-slate-500 dark:text-slate-400 block">Root Dir</span>
                        <strong className="text-[#0B1F3A] dark:text-white">./</strong>
                      </div>
                      <div className="p-2.5">
                        <span className="text-[10px] uppercase tracking-wider text-slate-500 dark:text-slate-400 block">Build Cmd</span>
                        <strong className="text-[#0B1F3A] dark:text-white font-mono text-[11px]">npm run build</strong>
                      </div>
                      <div className="p-2.5">
                        <span className="text-[10px] uppercase tracking-wider text-slate-500 dark:text-slate-400 block">Output Dir</span>
                        <strong className="text-[#0B1F3A] dark:text-white font-mono text-[11px]">dist</strong>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Step 4: Get your live link */}
                <div className="p-5 flex gap-4 items-start">
                  <div className="w-7 h-7 rounded-md bg-emerald-600 text-white font-bold text-xs flex items-center justify-center flex-none">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold text-sm text-[#0B1F3A] dark:text-white">
                      Your Live Link is Ready
                    </h4>
                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">
                      Within 30–60 seconds, Vercel gives you your live URL, such as:
                    </p>
                    <div className="mt-2 p-2.5 bg-[#F8FAFC] dark:bg-[#061121] text-[#0B1F3A] dark:text-sky-200 rounded-lg text-xs font-mono font-semibold inline-block border border-slate-200 dark:border-sky-200/20">
                      https://saint-michael-high-school.vercel.app
                    </div>
                  </div>
                </div>
              </div>

            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="bg-[#0B1F3A] text-slate-300 p-3.5 px-6 flex items-center justify-between text-xs border-t border-sky-200/20 flex-none">
          <span className="flex items-center gap-1.5">
            <Globe className="w-3.5 h-3.5 text-sky-300" /> Fully compatible with GitHub, Vercel, Netlify, and Cloudflare Pages
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-white text-[#0B1F3A] font-semibold hover:bg-sky-100 transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};

