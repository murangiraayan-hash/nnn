export type Language = 'en' | 'rw';
export type Theme = 'light' | 'dark';

export type ProgramId = 'p1' | 'p2' | 'p3' | 'p4' | 'p5';

export interface Program {
  id: ProgramId;
  nameKey: string;
  descKey: string;
  fullNameEn: string;
  fullNameRw: string;
  duration: string;
  award: string;
  modules: string[];
  careers: string[];
  iconSvg: string;
}

export interface StudentRegistration {
  id: string;
  regCode: string;
  name: string;
  dob: string;
  district: string;
  school: string;
  prog: ProgramId;
  parent: string;
  phone: string;
  email?: string;
  msg?: string;
  status: 'pending' | 'verified' | 'admitted';
  createdAt: string;
}

export interface PaymentRecord {
  id: string;
  regCode?: string;
  studentName: string;
  phone: string;
  prog: ProgramId;
  method: 'momo' | 'bk' | 'bpr' | 'equity';
  amount: number;
  itemType: 'registration' | 'term_tuition' | 'uniform' | 'materials' | 'full_package';
  refNumber: string;
  status: 'completed' | 'pending_verification';
  createdAt: string;
}

export interface PhpFile {
  name: string;
  filename: string;
  language: string;
  description: string;
  code: string;
}
