import React, { useState, useEffect } from 'react';
import { Language, Theme, ProgramId, StudentRegistration } from './types/index.ts';
import { Navbar } from './components/Navbar.tsx';
import { Hero } from './components/Hero.tsx';
import { ProgramsSection } from './components/ProgramsSection.tsx';
import { FeesAndPayment } from './components/FeesAndPayment.tsx';
import { RegistrationSection } from './components/RegistrationSection.tsx';
import { ContactSection } from './components/ContactSection.tsx';
import { Footer } from './components/Footer.tsx';
import { PhpBackendCenter } from './components/PhpBackendCenter.tsx';
import { AdminPortal } from './components/AdminPortal.tsx';
import { DownloadModal } from './components/DownloadModal.tsx';
import { storageService } from './services/storageService.ts';
import { CheckCircle2 } from 'lucide-react';

export default function App() {
  const [lang, setLang] = useState<Language>(() => {
    try {
      return (localStorage.getItem('smths_lang') as Language) || 'en';
    } catch {
      return 'en';
    }
  });

  const [theme, setTheme] = useState<Theme>(() => {
    try {
      return (localStorage.getItem('smths_theme') as Theme) || 'light';
    } catch {
      return 'light';
    }
  });

  const [selectedProgram, setSelectedProgram] = useState<ProgramId>('p1');
  const [isPhpCenterOpen, setIsPhpCenterOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isDownloadOpen, setIsDownloadOpen] = useState(false);
  const [studentCount, setStudentCount] = useState(0);
  const [notification, setNotification] = useState<string | null>(null);

  // Sync theme with HTML class
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    try {
      localStorage.setItem('smths_theme', theme);
    } catch {}
  }, [theme]);

  // Sync lang with LocalStorage & html tag
  useEffect(() => {
    document.documentElement.lang = lang;
    try {
      localStorage.setItem('smths_lang', lang);
    } catch {}
  }, [lang]);

  // Load student count
  const refreshStats = () => {
    const list = storageService.getRegistrations();
    setStudentCount(list.length);
  };

  useEffect(() => {
    refreshStats();
  }, []);

  const handleToggleLang = () => {
    setLang((prev) => (prev === 'en' ? 'rw' : 'en'));
  };

  const handleToggleTheme = () => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  const handleSelectProgramFromCards = (progId: ProgramId) => {
    setSelectedProgram(progId);
    const registerEl = document.getElementById('register');
    if (registerEl) {
      registerEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleRegistrationComplete = (reg: StudentRegistration) => {
    refreshStats();
    showToast(
      lang === 'en'
        ? `Registration ${reg.regCode} saved for ${reg.name}!`
        : `Iyandikishwa ${reg.regCode} ryabitswe kuri ${reg.name}!`
    );
  };

  const handlePaymentSuccess = () => {
    refreshStats();
    showToast(
      lang === 'en'
        ? 'Fee payment recorded and verified with digital receipt!'
        : 'Ubwishyu bwemejwe neza hamwe n\'inyemezabwishyu!'
    );
  };

  const showToast = (msg: string) => {
    setNotification(msg);
    setTimeout(() => {
      setNotification(null);
    }, 4500);
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] dark:bg-[#061121] bg-hairline-grid text-[#0B1F3A] dark:text-[#E2E8F0] transition-colors duration-200 flex flex-col font-sans">
      
      {/* Floating Toast Notification */}
      {notification && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#0B1F3A] text-white border border-sky-200/30 px-4 py-3 rounded-xl shadow-xl flex items-center gap-3">
          <CheckCircle2 className="w-5 h-5 text-sky-300 flex-none" />
          <span className="text-xs sm:text-sm font-semibold">{notification}</span>
        </div>
      )}

      {/* Navigation */}
      <Navbar
        lang={lang}
        onToggleLang={handleToggleLang}
        theme={theme}
        onToggleTheme={handleToggleTheme}
        onOpenPhpCenter={() => setIsPhpCenterOpen(true)}
        onOpenAdmin={() => setIsAdminOpen(true)}
        onOpenDownload={() => setIsDownloadOpen(true)}
        studentCount={studentCount}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        <Hero lang={lang} />
        
        <ProgramsSection
          lang={lang}
          onSelectProgram={handleSelectProgramFromCards}
        />
        
        <FeesAndPayment
          lang={lang}
          onPaymentSuccess={handlePaymentSuccess}
          defaultProgram={selectedProgram}
        />
        
        <RegistrationSection
          lang={lang}
          selectedProgram={selectedProgram}
          onRegistrationComplete={handleRegistrationComplete}
          onOpenPhpCenter={() => setIsPhpCenterOpen(true)}
        />
        
        <ContactSection lang={lang} />
      </main>

      {/* Footer */}
      <Footer
        lang={lang}
        onOpenPhpCenter={() => setIsPhpCenterOpen(true)}
        onOpenAdmin={() => setIsAdminOpen(true)}
      />

      {/* Interactive PHP Backend & MySQL Code Center Modal */}
      <PhpBackendCenter
        isOpen={isPhpCenterOpen}
        onClose={() => setIsPhpCenterOpen(false)}
      />

      {/* School Admin Portal Modal */}
      <AdminPortal
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        lang={lang}
        onRefresh={refreshStats}
      />

      {/* Download Project & Code ZIP Modal */}
      <DownloadModal
        isOpen={isDownloadOpen}
        onClose={() => setIsDownloadOpen(false)}
      />

    </div>
  );
}
