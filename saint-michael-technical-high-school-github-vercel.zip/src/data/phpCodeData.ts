import { PhpFile } from '../types/index.ts';

export const PHP_FILES: PhpFile[] = [
  {
    name: 'Database Schema (MySQL)',
    filename: 'database.sql',
    language: 'sql',
    description: 'MySQL database setup script. Run this in phpMyAdmin to create the database, tables, and sample data.',
    code: `-- ========================================================
-- Saint Michael Technical High School
-- Database Schema for Student Registration & Fee Payments
-- Compatible with MySQL 5.7+, MySQL 8.0, and MariaDB
-- ========================================================

-- 1. Create Database
CREATE DATABASE IF NOT EXISTS \`smths_school_db\`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE \`smths_school_db\`;

-- 2. Table: Programs / Technical Trades
CREATE TABLE IF NOT EXISTS \`programs\` (
  \`id\` VARCHAR(10) PRIMARY KEY,
  \`name_en\` VARCHAR(150) NOT NULL,
  \`name_rw\` VARCHAR(150) NOT NULL,
  \`duration_years\` INT DEFAULT 3,
  \`award\` VARCHAR(150) NOT NULL,
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Seed Programs
INSERT IGNORE INTO \`programs\` (\`id\`, \`name_en\`, \`name_rw\`, \`award\`) VALUES
('p1', 'Software Development', 'Gukora Porogaramu za Mudasobwa', 'National TVET Diploma Level 5'),
('p2', 'Food and Beverage Operations', 'Ibiribwa n\\'Ibinyobwa (Culinary)', 'National TVET Diploma Level 5'),
('p3', 'Computer Systems & Networks', 'Sisitemu za Mudasobwa', 'National TVET Diploma Level 5'),
('p4', 'Architecture & Structural Design', 'Ubwubatsi n\\'Igishushanyo', 'National TVET Diploma Level 5'),
('p5', 'Multimedia Production', 'Multimedia n\\'Ubugeni bw\\'Amashusho', 'National TVET Diploma Level 5');

-- 3. Table: Student Registrations
CREATE TABLE IF NOT EXISTS \`registrations\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`reg_code\` VARCHAR(30) NOT NULL UNIQUE,
  \`full_name\` VARCHAR(150) NOT NULL,
  \`dob\` DATE NOT NULL,
  \`district\` VARCHAR(100) NOT NULL,
  \`previous_school\` VARCHAR(150) DEFAULT NULL,
  \`program_id\` VARCHAR(10) NOT NULL,
  \`parent_name\` VARCHAR(150) NOT NULL,
  \`parent_phone\` VARCHAR(30) NOT NULL,
  \`email\` VARCHAR(100) DEFAULT NULL,
  \`notes\` TEXT DEFAULT NULL,
  \`status\` ENUM('pending', 'verified', 'admitted') DEFAULT 'pending',
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX \`idx_program\` (\`program_id\`),
  INDEX \`idx_phone\` (\`parent_phone\`),
  FOREIGN KEY (\`program_id\`) REFERENCES \`programs\`(\`id\`) ON UPDATE CASCADE
) ENGINE=InnoDB;

-- 4. Table: Fee Payments
CREATE TABLE IF NOT EXISTS \`payments\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`txn_ref\` VARCHAR(50) NOT NULL UNIQUE,
  \`reg_code\` VARCHAR(30) DEFAULT NULL,
  \`student_name\` VARCHAR(150) NOT NULL,
  \`phone\` VARCHAR(30) NOT NULL,
  \`program_id\` VARCHAR(10) NOT NULL,
  \`payment_method\` ENUM('momo', 'bk', 'bpr', 'equity') NOT NULL,
  \`amount_rwf\` DECIMAL(10, 2) NOT NULL,
  \`item_type\` VARCHAR(50) NOT NULL,
  \`status\` ENUM('completed', 'pending_verification') DEFAULT 'completed',
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX \`idx_txn\` (\`txn_ref\`),
  FOREIGN KEY (\`program_id\`) REFERENCES \`programs\`(\`id\`) ON UPDATE CASCADE
) ENGINE=InnoDB;

-- Sample Seed Data
INSERT IGNORE INTO \`registrations\` (\`reg_code\`, \`full_name\`, \`dob\`, \`district\`, \`previous_school\`, \`program_id\`, \`parent_name\`, \`parent_phone\`, \`status\`) VALUES
('SMTHS-2025-0101', 'Mugisha Emmanuel', '2007-04-12', 'Gasabo, Kigali', 'GS Remera Protestant', 'p1', 'Habimana Jean Bosco', '0788123456', 'admitted'),
('SMTHS-2025-0102', 'Keza Diane', '2008-01-24', 'Kicukiro, Kigali', 'Kagarama Secondary', 'p2', 'Mukamana Claudine', '0788654321', 'verified'),
('SMTHS-2025-0103', 'Uwase Aline', '2007-09-18', 'Nyarugenge, Kigali', 'Camp Kigali School', 'p5', 'Karasira Patrick', '0788998877', 'pending');

INSERT IGNORE INTO \`payments\` (\`txn_ref\`, \`reg_code\`, \`student_name\`, \`phone\`, \`program_id\`, \`payment_method\`, \`amount_rwf\`, \`item_type\`) VALUES
('TXN-MOMO-94821', 'SMTHS-2025-0101', 'Mugisha Emmanuel', '0788123456', 'p1', 'momo', 20000.00, 'registration'),
('TXN-BK-110492', 'SMTHS-2025-0102', 'Keza Diane', '0788654321', 'p2', 'bk', 120000.00, 'term_tuition');
`
  },
  {
    name: 'Database Configuration',
    filename: 'config.php',
    language: 'php',
    description: 'Database connection configuration using PHP PDO with secure error handling and CORS support for web clients.',
    code: `<?php
/**
 * Saint Michael Technical High School
 * Database Connection & Environment Configuration
 * File: config.php
 */

// 1. Database Credentials (Adjust for your XAMPP or production hosting)
define('DB_HOST', 'localhost');
define('DB_NAME', 'smths_school_db');
define('DB_USER', 'root');      // Default XAMPP username is 'root'
define('DB_PASS', '');          // Default XAMPP password is empty ''
define('DB_CHARSET', 'utf8mb4');

// 2. CORS Headers (Allows front-end JavaScript to communicate with PHP)
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json; charset=UTF-8');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// 3. PDO Connection
function getDbConnection() {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'error'   => 'Database connection error: ' . $e->getMessage()
            ]);
            exit();
        }
    }
    return $pdo;
}

// 4. Helper Function: JSON Response
function sendJsonResponse($success, $data = [], $message = '', $statusCode = 200) {
    http_response_code($statusCode);
    echo json_encode(array_merge([
        'success'   => $success,
        'message'   => $message,
        'timestamp' => date('Y-m-d H:i:s')
    ], $data));
    exit();
}
?>`
  },
  {
    name: 'Student Registration API',
    filename: 'register.php',
    language: 'php',
    description: 'Receives student registration data via POST, validates required fields, inserts into MySQL via prepared statements, and returns confirmation JSON.',
    code: `<?php
/**
 * Saint Michael Technical High School
 * Student Registration Endpoint
 * File: register.php
 */

require_once __DIR__ . '/config.php';

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJsonResponse(false, [], 'Method Not Allowed. Use POST.', 405);
}

// 1. Read Input (Handles both JSON payloads from fetch() and traditional HTML Form POST)
$rawInput = file_get_contents('php://input');
$data = json_decode($rawInput, true);

if (!$data) {
    $data = $_POST;
}

// 2. Validate Required Fields
$requiredFields = ['name', 'dob', 'district', 'prog', 'parent', 'phone'];
$missing = [];

foreach ($requiredFields as $field) {
    if (empty($data[$field]) || trim($data[$field]) === '') {
        $missing[] = $field;
    }
}

if (!empty($missing)) {
    sendJsonResponse(false, ['missing_fields' => $missing], 'Missing required fields: ' . implode(', ', $missing), 400);
}

// 3. Sanitize and Extract Fields
$fullName = htmlspecialchars(trim($data['name']), ENT_QUOTES, 'UTF-8');
$dob      = trim($data['dob']);
$district = htmlspecialchars(trim($data['district']), ENT_QUOTES, 'UTF-8');
$school   = !empty($data['school']) ? htmlspecialchars(trim($data['school']), ENT_QUOTES, 'UTF-8') : null;
$prog     = trim($data['prog']);
$parent   = htmlspecialchars(trim($data['parent']), ENT_QUOTES, 'UTF-8');
$phone    = htmlspecialchars(trim($data['phone']), ENT_QUOTES, 'UTF-8');
$email    = !empty($data['email']) ? filter_var(trim($data['email']), FILTER_SANITIZE_EMAIL) : null;
$notes    = !empty($data['msg']) ? htmlspecialchars(trim($data['msg']), ENT_QUOTES, 'UTF-8') : null;

// Validate Program Key
$allowedPrograms = ['p1', 'p2', 'p3', 'p4', 'p5'];
if (!in_array($prog, $allowedPrograms)) {
    sendJsonResponse(false, [], 'Invalid program selected.', 400);
}

// 4. Generate Unique Registration Code (e.g. SMTHS-2025-XXXX)
$year = date('Y');
$randomNumber = str_pad(mt_rand(100, 9999), 4, '0', STR_PAD_LEFT);
$regCode = "SMTHS-{$year}-{$randomNumber}";

// 5. Insert Record using PDO Prepared Statement (Prevents SQL Injection)
try {
    $pdo = getDbConnection();

    $stmt = $pdo->prepare("
        INSERT INTO registrations 
        (reg_code, full_name, dob, district, previous_school, program_id, parent_name, parent_phone, email, notes, status)
        VALUES 
        (:reg_code, :full_name, :dob, :district, :previous_school, :program_id, :parent_name, :parent_phone, :email, :notes, 'pending')
    ");

    $stmt->execute([
        ':reg_code'        => $regCode,
        ':full_name'       => $fullName,
        ':dob'             => $dob,
        ':district'        => $district,
        ':previous_school' => $school,
        ':program_id'      => $prog,
        ':parent_name'     => $parent,
        ':parent_phone'    => $phone,
        ':email'           => $email,
        ':notes'           => $notes,
    ]);

    $insertedId = $pdo->lastInsertId();

    sendJsonResponse(true, [
        'registration_id' => $insertedId,
        'reg_code'        => $regCode,
        'student_name'    => $fullName,
        'program'         => $prog,
        'status'          => 'pending',
        'whatsapp_message' => "Saint Michael Registration\\nName: {$fullName}\\nCode: {$regCode}\\nTrade: {$prog}\\nParent: {$parent} ({$phone})"
    ], 'Registration successfully saved in the database!', 201);

} catch (PDOException $e) {
    sendJsonResponse(false, ['error_detail' => $e->getMessage()], 'Failed to save student registration.', 500);
}
?>`
  },
  {
    name: 'Fee Payment Processing API',
    filename: 'pay.php',
    language: 'php',
    description: 'Endpoint to record student fee payments (MoMo, BK, BPR, Equity), update payment status, and generate digital receipt reference.',
    code: `<?php
/**
 * Saint Michael Technical High School
 * Fee Payment Processing Endpoint
 * File: pay.php
 */

require_once __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJsonResponse(false, [], 'Method Not Allowed. Use POST.', 405);
}

$rawInput = file_get_contents('php://input');
$data = json_decode($rawInput, true);

if (!$data) {
    $data = $_POST;
}

// Required fields for payment
$name    = isset($data['name']) ? trim($data['name']) : '';
$phone   = isset($data['phone']) ? trim($data['phone']) : '';
$prog    = isset($data['prog']) ? trim($data['prog']) : '';
$method  = isset($data['method']) ? trim($data['method']) : '';
$amount  = isset($data['amount']) ? floatval($data['amount']) : 20000;
$item    = isset($data['item']) ? trim($data['item']) : 'registration';
$regCode = isset($data['regCode']) ? trim($data['regCode']) : null;

if (empty($name) || empty($phone) || empty($prog) || empty($method)) {
    sendJsonResponse(false, [], 'Missing student name, phone, program, or payment method.', 400);
}

// Generate Unique Transaction Reference (e.g. TXN-MOMO-84920)
$methodPrefix = strtoupper($method);
$txnRef = "TXN-{$methodPrefix}-" . mt_rand(10000, 99999);

try {
    $pdo = getDbConnection();

    $stmt = $pdo->prepare("
        INSERT INTO payments 
        (txn_ref, reg_code, student_name, phone, program_id, payment_method, amount_rwf, item_type, status)
        VALUES 
        (:txn_ref, :reg_code, :student_name, :phone, :program_id, :payment_method, :amount_rwf, :item_type, 'completed')
    ");

    $stmt->execute([
        ':txn_ref'        => $txnRef,
        ':reg_code'       => $regCode,
        ':student_name'   => $name,
        ':phone'          => $phone,
        ':program_id'     => $prog,
        ':payment_method' => $method,
        ':amount_rwf'     => $amount,
        ':item_type'      => $item,
    ]);

    // If a registration code was provided, mark registration as verified
    if ($regCode) {
        $updateStmt = $pdo->prepare("UPDATE registrations SET status = 'verified' WHERE reg_code = :reg_code");
        $updateStmt->execute([':reg_code' => $regCode]);
    }

    sendJsonResponse(true, [
        'transaction_ref' => $txnRef,
        'student_name'    => $name,
        'amount_rwf'      => $amount,
        'method'          => $method,
        'item'            => $item,
        'receipt_note'    => 'Payment received by Saint Michael Technical High School. Please present this reference at school.'
    ], 'Fee payment recorded successfully!', 201);

} catch (PDOException $e) {
    sendJsonResponse(false, ['error' => $e->getMessage()], 'Failed to record payment.', 500);
}
?>`
  },
  {
    name: 'Get Records API',
    filename: 'get_students.php',
    language: 'php',
    description: 'Fetches student registrations and payments with search and filtering for administrative reports.',
    code: `<?php
/**
 * Saint Michael Technical High School
 * Fetch Student Records & Administrative Reports
 * File: get_students.php
 */

require_once __DIR__ . '/config.php';

try {
    $pdo = getDbConnection();

    // Query parameters
    $program = isset($_GET['prog']) ? trim($_GET['prog']) : null;
    $status  = isset($_GET['status']) ? trim($_GET['status']) : null;
    $search  = isset($_GET['search']) ? trim($_GET['search']) : null;

    $sql = "
        SELECT r.*, p.name_en AS program_title, p.award
        FROM registrations r
        LEFT JOIN programs p ON r.program_id = p.id
        WHERE 1=1
    ";
    $params = [];

    if ($program) {
        $sql .= " AND r.program_id = :program";
        $params[':program'] = $program;
    }
    if ($status) {
        $sql .= " AND r.status = :status";
        $params[':status'] = $status;
    }
    if ($search) {
        $sql .= " AND (r.full_name LIKE :search OR r.reg_code LIKE :search OR r.parent_phone LIKE :search)";
        $params[':search'] = "%{$search}%";
    }

    $sql .= " ORDER BY r.created_at DESC LIMIT 100";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $students = $stmt->fetchAll();

    // Also get summary counts
    $countStmt = $pdo->query("SELECT COUNT(*) as total_students FROM registrations");
    $totalStudents = $countStmt->fetch()['total_students'];

    $paymentStmt = $pdo->query("SELECT SUM(amount_rwf) as total_fees FROM payments");
    $totalFees = $paymentStmt->fetch()['total_fees'] ?? 0;

    sendJsonResponse(true, [
        'count'          => count($students),
        'total_students' => (int)$totalStudents,
        'total_fees_rwf' => (float)$totalFees,
        'students'       => $students
    ], 'Students fetched successfully.');

} catch (PDOException $e) {
    sendJsonResponse(false, ['error' => $e->getMessage()], 'Failed to fetch records.', 500);
}
?>`
  },
  {
    name: 'Standalone Admin Portal',
    filename: 'admin.php',
    language: 'php',
    description: 'A complete, self-contained PHP admin dashboard you can open directly at http://localhost/smths_backend/admin.php with CSV export.',
    code: `<?php
/**
 * Saint Michael Technical High School
 * Standalone Admin Portal & CSV Exporter
 * File: admin.php
 */

require_once __DIR__ . '/config.php';
$pdo = getDbConnection();

// Handle CSV Export
if (isset($_GET['action']) && $_GET['action'] === 'export_csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=SMTHS_Students_' . date('Y-m-d') . '.csv');
    
    $output = fopen('php://output', 'w');
    fputcsv($output, ['ID', 'Reg Code', 'Full Name', 'Date of Birth', 'District', 'Program', 'Parent Name', 'Parent Phone', 'Email', 'Status', 'Date']);
    
    $stmt = $pdo->query("SELECT * FROM registrations ORDER BY id DESC");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        fputcsv($output, [
            $row['id'], $row['reg_code'], $row['full_name'], $row['dob'], 
            $row['district'], $row['program_id'], $row['parent_name'], 
            $row['parent_phone'], $row['email'], $row['status'], $row['created_at']
        ]);
    }
    fclose($output);
    exit();
}

// Fetch stats
$totalStudents = $pdo->query("SELECT COUNT(*) FROM registrations")->fetchColumn();
$totalPayments = $pdo->query("SELECT COALESCE(SUM(amount_rwf), 0) FROM payments")->fetchColumn();
$recentStudents = $pdo->query("SELECT * FROM registrations ORDER BY id DESC LIMIT 50")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Saint Michael THS - Admin Portal</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #F8FAFC; color: #0B1F3A; margin: 0; padding: 24px; }
        .container { max-width: 1100px; margin: 0 auto; background: #fff; padding: 28px; border-radius: 12px; border: 1px solid #CBD5E1; box-shadow: 0 8px 24px rgba(11,31,58,0.06); }
        header { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #E2E8F0; padding-bottom: 16px; margin-bottom: 24px; }
        h1 { margin: 0; color: #0B1F3A; font-size: 1.5rem; }
        .stats { display: flex; gap: 20px; margin-bottom: 24px; }
        .stat-card { flex: 1; background: #F1F5F9; padding: 18px; border-radius: 10px; border: 1px solid #CBD5E1; }
        .stat-card b { display: block; font-size: 0.8rem; text-transform: uppercase; color: #475569; }
        .stat-card span { font-size: 1.8rem; font-weight: bold; color: #0B1F3A; }
        table { width: 100%; border-collapse: collapse; margin-top: 14px; border: 1px solid #E2E8F0; }
        th, td { border-bottom: 1px solid #E2E8F0; padding: 10px 14px; text-align: left; }
        th { background: #0B1F3A; color: #fff; font-weight: 600; }
        tr:nth-child(even) { background: #F8FAFC; }
        .btn { display: inline-block; background: #0B1F3A; color: #fff; padding: 10px 18px; text-decoration: none; border-radius: 6px; font-weight: 600; }
        .badge { font-size: 0.8rem; font-weight: 600; }
        .badge.pending { color: #92400E; }
        .badge.verified { color: #065F46; }
        .badge.admitted { color: #1E40AF; }
    </style>
</head>
<body>
<div class="container">
    <header>
        <div>
            <h1>Saint Michael Technical High School</h1>
            <p>Admin Database & Registration Portal (PHP + MySQL)</p>
        </div>
        <a href="?action=export_csv" class="btn">📥 Export to CSV</a>
    </header>

    <div class="stats">
        <div class="stat-card">
            <b>Total Registered Students</b>
            <span><?= number_format($totalStudents) ?></span>
        </div>
        <div class="stat-card">
            <b>Total Fees Collected</b>
            <span><?= number_format($totalPayments) ?> RWF</span>
        </div>
    </div>

    <h2>Registered Students List</h2>
    <table>
        <thead>
            <tr>
                <th>Reg Code</th>
                <th>Full Name</th>
                <th>Trade</th>
                <th>District</th>
                <th>Parent Phone</th>
                <th>Status</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($recentStudents)): ?>
                <tr><td colspan="7" style="text-align:center;">No student registrations yet.</td></tr>
            <?php else: ?>
                <?php foreach ($recentStudents as $s): ?>
                <tr>
                    <td><strong><?= htmlspecialchars($s['reg_code']) ?></strong></td>
                    <td><?= htmlspecialchars($s['full_name']) ?></td>
                    <td><?= htmlspecialchars(strtoupper($s['program_id'])) ?></td>
                    <td><?= htmlspecialchars($s['district']) ?></td>
                    <td><?= htmlspecialchars($s['parent_phone']) ?></td>
                    <td><span class="badge <?= htmlspecialchars($s['status']) ?>"><?= ucfirst($s['status']) ?></span></td>
                    <td><?= htmlspecialchars(substr($s['created_at'], 0, 10)) ?></td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html>`
  },
  {
    name: 'XAMPP & Setup Guide',
    filename: 'README_XAMPP.md',
    language: 'markdown',
    description: 'Easy, step-by-step instructions on setting up XAMPP, creating the MySQL database, running the PHP backend, and connecting forms.',
    code: `# Saint Michael Technical High School - PHP Backend Setup Guide

This guide walks you through hosting the PHP backend on your computer using **XAMPP** (or WAMP / MAMP / LAMP).

---

## 1. Download & Install XAMPP
1. Download XAMPP from [apachefriends.org](https://www.apachefriends.org/).
2. Run the installer and install **Apache** and **MySQL**.
3. Open the **XAMPP Control Panel** and click **Start** next to Apache and MySQL.

---

## 2. Place Backend Files in htdocs
1. Navigate to your XAMPP web directory:
   - On Windows: \`C:\\xampp\\htdocs\\\`
   - On Mac: \`/Applications/XAMPP/htdocs/\`
   - On Linux: \`/opt/lampp/htdocs/\`
2. Create a new folder named \`smths_backend\`:
   \`\`\`
   C:\\xampp\\htdocs\\smths_backend\\
   \`\`\`
3. Put the following PHP files into that folder:
   - \`config.php\`
   - \`register.php\`
   - \`pay.php\`
   - \`get_students.php\`
   - \`admin.php\`

---

## 3. Create the Database in phpMyAdmin
1. Open your web browser and go to:
   \`http://localhost/phpmyadmin\`
2. Click on the **SQL** tab at the top.
3. Open the \`database.sql\` file, copy all its content, and paste it into the SQL box.
4. Click **Go** (bottom right).
5. It will create the database \`smths_school_db\` with tables \`programs\`, \`registrations\`, and \`payments\`.

---

## 4. Test Your PHP Backend
1. **Test Registration Form in browser or Postman:**
   Send a \`POST\` request to:
   \`\`\`
   http://localhost/smths_backend/register.php
   \`\`\`
   Sample JSON body:
   \`\`\`json
   {
     "name": "Kwizera Jean",
     "dob": "2007-06-15",
     "district": "Gasabo, Kigali",
     "school": "Kigali Secondary School",
     "prog": "p1",
     "parent": "Mutesi Alice",
     "phone": "0788112233",
     "email": "jean@example.com",
     "msg": "Interested in software development"
   }
   \`\`\`

2. **Open the Admin Portal:**
   Visit in your browser:
   \`\`\`
   http://localhost/smths_backend/admin.php
   \`\`\`
   You will see all registered students and an "Export to CSV" button.

---

## 5. Connecting with an HTML Form
If you want to use a pure HTML form without JavaScript, write:
\`\`\`html
<form action="http://localhost/smths_backend/register.php" method="POST">
  <input type="text" name="name" placeholder="Student Full Name" required>
  <input type="date" name="dob" required>
  <input type="text" name="district" placeholder="District" required>
  <select name="prog" required>
    <option value="p1">Software Development</option>
    <option value="p2">Food and Beverage</option>
    <option value="p3">Computer Systems</option>
    <option value="p4">Architecture</option>
    <option value="p5">Multimedia</option>
  </select>
  <input type="text" name="parent" placeholder="Parent Name" required>
  <input type="tel" name="phone" placeholder="Parent Phone" required>
  <button type="submit">Submit to PHP Database</button>
</form>
\`\`\`

---

## 6. Common Issues & Solutions
- **Error: "Access denied for user 'root'@'localhost'"**:
  Check \`config.php\`. If your MySQL has a password, change \`define('DB_PASS', 'your_password');\`.
- **Error: CORS blocked in browser**:
  Ensure the header \`header('Access-Control-Allow-Origin: *');\` is present in \`config.php\`.
- **PHP extension PDO not loaded**:
  In \`php.ini\`, ensure the line \`extension=pdo_mysql\` does not have a semicolon at the beginning.
`
  }
];
