import { Program } from '../types/index.ts';

export const PROGRAMS: Program[] = [
  {
    id: 'p1',
    nameKey: 'p1',
    descKey: 'p1d',
    fullNameEn: 'Software Development & Web Engineering',
    fullNameRw: 'Gukora Porogaramu za Mudasobwa n\'Imbuga za Interineti',
    duration: '3 Years (RTQF Level 3-5)',
    award: 'National TVET Diploma in Software Development',
    modules: ['HTML/CSS & JavaScript', 'PHP & MySQL Databases', 'Python & Algorithms', 'Mobile App Development', 'Git & Software Testing'],
    careers: ['Junior Web Developer', 'Database Assistant', 'Front-End Specialist', 'IT Support Technician'],
    iconSvg: `<circle class="ring" cx="100" cy="100" r="94"/><g transform="translate(100 104) scale(.7) translate(-100 -100)"><circle cx="65" cy="82" r="11"/><path d="M65 93v42M65 108L108 122M65 135h42v35M40 172h140M107 135l-10 0"/><path d="M110 118h62M118 118l5-50h46l5 50"/><path d="M137 86l-9 10 9 10M155 86l9 10-9 10"/></g>`
  },
  {
    id: 'p2',
    nameKey: 'p2',
    descKey: 'p2d',
    fullNameEn: 'Food and Beverage Operations & Culinary Arts',
    fullNameRw: 'Ibiribwa n\'Ibinyobwa (Culinary Arts & Hospitality)',
    duration: '3 Years (RTQF Level 3-5)',
    award: 'National TVET Diploma in Culinary & Hospitality Operations',
    modules: ['Commercial Cookery & Baking', 'Food Safety & HACCP', 'Bar & Beverage Management', 'Customer Service & Banqueting', 'Cost Control & Menu Engineering'],
    careers: ['Professional Chef', 'Catering Supervisor', 'Restaurant Manager', 'Pastry Specialist'],
    iconSvg: `<circle class="ring" cx="100" cy="100" r="94"/><g transform="translate(100 104) scale(.7) translate(-100 -100)"><circle cx="75" cy="78" r="10"/><path d="M62 70h26v-7c10-4 8-18-5-17-3-9-17-9-21 0-12-1-14 13-4 17z"/><path d="M75 88v40M75 104L112 116M75 104L102 122M75 128L62 172M75 128L88 172"/><rect x="104" y="116" width="46" height="28" rx="5"/><path d="M95 144h70M105 144v28M155 144v28M118 106c-5-7 5-9 0-17M136 106c-5-7 5-9 0-17"/></g>`
  },
  {
    id: 'p3',
    nameKey: 'p3',
    descKey: 'p3d',
    fullNameEn: 'Computer Systems & Network Technology',
    fullNameRw: 'Sisitemu za Mudasobwa n\'Imiyoboro ya Interineti',
    duration: '3 Years (RTQF Level 3-5)',
    award: 'National TVET Diploma in Computer Systems Architecture',
    modules: ['Hardware Troubleshooting & PC Repair', 'Cisco CCNA Networking Basics', 'Linux & Windows Server Admin', 'Cybersecurity Fundamentals', 'Fiber Optic & LAN Cabling'],
    careers: ['Network Administrator', 'Systems Support Specialist', 'Field Service Technician', 'Help Desk Lead'],
    iconSvg: `<circle class="ring" cx="100" cy="100" r="94"/><g transform="translate(100 104) scale(.7) translate(-100 -100)"><circle cx="62" cy="78" r="10"/><path d="M62 88v32M62 120L48 168M62 120L76 168M62 100L100 92M62 100L46 120"/><rect x="104" y="58" width="72" height="54" rx="6"/><path d="M140 112v22M118 136h44M114 72h36M114 86h50M114 100h24"/></g>`
  },
  {
    id: 'p4',
    nameKey: 'p4',
    descKey: 'p4d',
    fullNameEn: 'Architectural Drafting & Structural Design',
    fullNameRw: 'Ubwubatsi n\'Igishushanyo Mbonera (Architecture)',
    duration: '3 Years (RTQF Level 3-5)',
    award: 'National TVET Diploma in Architectural Technologies',
    modules: ['Architectural Drawing & Sketching', 'AutoCAD 2D & 3D Drafting', 'Building Codes & Material Estimates', 'Topography & Land Surveying', 'Structural Model Making'],
    careers: ['CAD Drafter', 'Site Assistant Supervisor', 'Architectural Modeler', 'Estimating Assistant'],
    iconSvg: `<circle class="ring" cx="100" cy="100" r="94"/><g transform="translate(100 104) scale(.7) translate(-100 -100)"><circle cx="62" cy="78" r="10"/><path d="M62 88v32M62 120L50 168M62 120L76 168M62 100L106 104M62 100L48 122"/><rect x="108" y="56" width="68" height="82"/><path d="M122 118v-24l20-14 20 14v24zM136 118v-12h12v12M125 138l-10 34M160 138l10 34"/></g>`
  },
  {
    id: 'p5',
    nameKey: 'p5',
    descKey: 'p5d',
    fullNameEn: 'Multimedia Production & Digital Arts',
    fullNameRw: 'Multimedia, Gufata Amashusho n\'Ibishushanyo',
    duration: '3 Years (RTQF Level 3-5)',
    award: 'National TVET Diploma in Digital Media & Audio-Visual Arts',
    modules: ['Digital Photography & Lighting', 'Video Editing (Premiere/DaVinci)', 'Graphic Design (Photoshop/Illustrator)', 'Motion Graphics & 2D Animation', 'Sound Design & Podcasting'],
    careers: ['Video Editor & Videographer', 'Graphic Designer', 'Motion Content Creator', 'Social Media Producer'],
    iconSvg: `<circle class="ring" cx="100" cy="100" r="94"/><g transform="translate(100 104) scale(.7) translate(-100 -100)"><circle cx="58" cy="80" r="10"/><path d="M58 90v34M58 124L46 170M58 124L72 170M58 104L82 100M58 104L82 108"/><rect x="82" y="94" width="28" height="22" rx="3"/><path d="M110 100l16-8v32l-16-8"/><circle cx="160" cy="80" r="10"/><path d="M160 90v34M160 124L148 170M160 124L172 170M160 104L176 86M160 104L144 116"/></g>`
  }
];

export const FEE_SCHEDULE = [
  { id: 'reg', labelKey: 'reg', amountRwf: 20000, description: 'One-off registration & admission processing fee' },
  { id: 'term', labelKey: 'term', amountRwf: 120000, description: 'Standard tuition fee per academic term (3 terms per year)' },
  { id: 'uni', labelKey: 'uni', amountRwf: 35000, description: 'Complete set of two uniforms + workshop overall + sports attire' },
  { id: 'mat', labelKey: 'mat', amountRwf: 25000, description: 'Practical workshop consumables, tools and digital library pass' },
];

export const PAYMENT_METHODS = {
  momo: {
    id: 'momo',
    name: 'MTN MoMo (Mobile Money)',
    code: '*182*8*1*054321#',
    accountName: 'Saint Michael Technical High School',
    instructions: 'Dial *182*8*1*054321# on your MTN phone, enter the amount, and confirm with your MoMo PIN. Save the transaction SMS.'
  },
  bk: {
    id: 'bk',
    name: 'Bank of Kigali (BK)',
    accountNumber: '00040-0694821-34',
    accountName: 'Saint Michael Technical High School',
    instructions: 'Pay at any BK branch counter, BK App, or BK Yacu agent. Reference student name on deposit slip.'
  },
  bpr: {
    id: 'bpr',
    name: 'BPR Bank (Banque Populaire du Rwanda)',
    accountNumber: '400-3498210-11',
    accountName: 'Saint Michael Technical High School',
    instructions: 'Deposit or transfer using BPR Mobile or over the counter. State student registration code.'
  },
  equity: {
    id: 'equity',
    name: 'Equity Bank Rwanda',
    accountNumber: '400211-098231',
    accountName: 'Saint Michael Technical High School',
    instructions: 'Pay via Eazzy24/7 or Equity agent. Keep the stamped bank receipt for submission at school.'
  }
};
