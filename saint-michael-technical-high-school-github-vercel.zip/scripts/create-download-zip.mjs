import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';

const rootDir = process.cwd();
const outputDir = path.join(rootDir, 'public', 'downloads');
if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir, { recursive: true });
}

const sourceZipPath = path.join(outputDir, 'saint-michael-technical-high-school.zip');
const sourceZipAltPath = path.join(outputDir, 'saint-michael-technical-high-school-github-vercel.zip');
const distZipPath = path.join(outputDir, 'saint-michael-compiled-website.zip');

const IGNORED_DIRS = new Set(['node_modules', '.git', 'dist', 'build', '.vercel', '.aistudio', '.cache', 'downloads']);
const IGNORED_FILES = new Set(['bun.lock', '.DS_Store']);

function addDirectoryToZip(dirPath, zipFolder, customIgnoredDirs = IGNORED_DIRS) {
  if (!fs.existsSync(dirPath)) return;
  const items = fs.readdirSync(dirPath);
  for (const item of items) {
    if (IGNORED_FILES.has(item)) continue;
    const fullPath = path.join(dirPath, item);
    const stat = fs.statSync(fullPath);

    if (stat.isDirectory()) {
      if (customIgnoredDirs.has(item)) continue;
      const subFolder = zipFolder.folder(item);
      addDirectoryToZip(fullPath, subFolder, customIgnoredDirs);
    } else if (stat.isFile()) {
      const content = fs.readFileSync(fullPath);
      zipFolder.file(item, content);
    }
  }
}

async function buildZips() {
  // 1. Source files for GitHub & Vercel
  console.log('Packaging project source files for GitHub and Vercel...');
  const sourceZip = new JSZip();
  addDirectoryToZip(rootDir, sourceZip);
  const sourceBuffer = await sourceZip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 9 },
  });
  fs.writeFileSync(sourceZipPath, sourceBuffer);
  fs.writeFileSync(sourceZipAltPath, sourceBuffer);
  console.log(`Source ZIP created: ${sourceZipPath} (${(sourceBuffer.length / 1024 / 1024).toFixed(2)} MB)`);

  // 2. Compiled dist if present
  const distDir = path.join(rootDir, 'dist');
  if (fs.existsSync(distDir)) {
    console.log('Packaging compiled dist folder...');
    const distZip = new JSZip();
    addDirectoryToZip(distDir, distZip, new Set(['downloads']));
    const distBuffer = await distZip.generateAsync({
      type: 'nodebuffer',
      compression: 'DEFLATE',
      compressionOptions: { level: 9 },
    });
    fs.writeFileSync(distZipPath, distBuffer);
    console.log(`Compiled ZIP created: ${distZipPath} (${(distBuffer.length / 1024 / 1024).toFixed(2)} MB)`);
  }
}

buildZips().catch((err) => {
  console.error('Error packaging zips:', err);
  process.exit(1);
});
